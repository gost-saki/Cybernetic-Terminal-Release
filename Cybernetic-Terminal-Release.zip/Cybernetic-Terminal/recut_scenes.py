"""Shot timing and glyph compositions for the faster Cybernetic edit."""
from bisect import bisect_right
import math
from typing import NamedTuple

from cybernetic import hash16, ease
from player import FONT, width
from visual_variation import SCENES, TOP, BOTTOM, BLUE, DEEP, VIOLET
from player import BRIGHT, DIM, NORMAL, WHITE


class Shot(NamedTuple):
    start: float
    scene: str
    word: str


SHOTS = tuple(Shot(*cue) for cue in (
    (0.00,"boot","LINK"),
    (.70,"pair","0 / 1"),(3.48,"helix","HOLD"),(6.45,"field","STAY"),
    (8.11,"barrier","NO PATH"),(10.44,"lyric","GO THROUGH"),
    (12.45,"pulsewater","HEARTS"),(14.07,"surface","WAVES"),
    (15.17,"routing","CONNECT"),(17.18,"zipper","JOIN"),
    (18.81,"starfield","UNISON"),(20.64,"reflections","DREAMS"),
    (22.44,"slices","DISTORTION"),(24.69,"clock","LAST"),
    (26.56,"radar","SEARCH"),(28.25,"beacon","CONTACT"),
    (29.84,"fracture","SYNTHETIC"),(32.08,"lyric","MAKE IT HURT"),
    (33.83,"tether","HOLD"),(35.41,"slices","LET GO"),
    (36.97,"archive","MEMORY"),(39.65,"prism","STORED"),
    (41.63,"whirlpool","UNDERTOW"),(43.27,"drain","PULLED"),
    (44.25,"flood","FLOODED"),(45.08,"breakfall","BITS"),(47.32,"lyric","TORN INTO BITS"),
    (48.84,"recovery","WRECKAGE"),(50.53,"beacon","TAKE ME"),
    (51.91,"title","CYBERNETIC"),(54.18,"typewall","WE ARE"),
    (55.58,"sink","DROWN"),(57.80,"gate",""),
    (58.71,"tunnel","DEPTH"),(59.85,"orbit","PRESSURE"),
    (61.38,"current","FLOW"),(62.28,"prism","FAULT"),(63.71,"drain","DROP"),
    (64.61,"lyric","GOING TO DROWN"),(65.47,"surface","RIPPLE"),
    (66.80,"slices","SLIP"),(68.65,"whirlpool","RETURN"),
    (69.56,"beacon","SIGNAL"),(70.08,"breakfall","BREAK"),
    (71.77,"typewall","CYBERNETIC"),(74.07,"reflections","AFTERIMAGE"),
    (76.82,"wavegrid","ECHO"),(80.46,"prism","RECOVER"),
    (84.62,"archive","SCAN"),(87.73,"tether","STANDBY"),
    (91.50,"reboot","RESTART"),(94.10,"clock","RETRY"),(96.45,"barrier","FAILED"),
    (98.72,"overwrite","OVERRIDE"),(101.31,"lyric","AS IT SINKS"),
    (103.41,"bookends","BEGIN / END"),
    (106.14,"zipper","RECONNECT"),(108.72,"pair","WHAT WE WERE"),
    (109.76,"switches","CONTROL"),(111.90,"slices","BETTER / WORSE"),
    (113.34,"moire","DISTORTION"),(115.31,"lyric","EVERY MOMENT"),
    (117.45,"contact","SEARCH"),(119.20,"beacon","CONTACT"),
    (120.72,"typewall","SYNTHETIC WORDS"),(122.44,"fracture","HURT"),
    (124.25,"tether","LET GO"),(125.98,"reflections","NOT READY"),
    (127.83,"archive","STORED DATA"),(130.10,"lattice","EVERMORE"),
    (132.32,"current","UNDERTOW"),(134.62,"drain","PULL"),
    (135.05,"damage","FLOODED"),(136.91,"flood","CIRCUIT"),
    (138.27,"breakfall","INTO BITS"),(139.63,"recovery","WRECKAGE"),
    (141.44,"queue","TAKE ME"),(142.46,"title","CYBERNETIC"),
    (144.62,"lyric","WE ARE CYBERNETIC"),(145.54,"typewall","CYBERNETIC"),
    (146.55,"sink","DROWN"),(147.35,"memory","BUFFER"),(148.26,"collapse",""),
    (149.17,"drain",""),(150.44,"gate",""),
    (151.22,"tunnel","DESCENT"),(151.90,"starfield","BREACH"),
    (153.26,"current","TURBULENCE"),(154.17,"surface","WAVE"),
    (155.22,"lyric","WE ARE GOING TO DROWN"),(156.90,"flood","SUBMERGE"),
    (158.26,"orbit","ORBIT"),(159.17,"prism","SHEAR"),
    (161.90,"pulsewater","PULSE"),(162.63,"typewall","CYBERNETIC"),
    (164.17,"lattice","SYNC"),(166.44,"helix","ECHO"),(168.72,"whirlpool","RETURN"),
    (169.17,"slices","RIFT"),(170.53,"breakfall","BREAK"),
    (172.80,"wavegrid","WAKE"),(174.17,"beacon","RECOVER"),
    (175.53,"current","SURGE"),(176.44,"surface","LAST WAVE"),
    (178.71,"drain","CUT"),
))
STARTS = tuple(shot.start for shot in SHOTS)


def shot_at(t):
    i=max(0,bisect_right(STARTS,t)-1)
    shot=SHOTS[i]
    end=STARTS[i+1] if i+1<len(STARTS) else 179.75
    return i,shot,end


class FrameScene(NamedTuple):
    t: float
    age: float
    phase: float
    bass: float
    seed: int
    word: str


def strbits(index,count,radix="01"):
    return "".join(radix[hash16(index+319*i)%len(radix)] for i in range(count))


def cipher(payload):
    return " ".join(f"{b:02X}" for b in payload.encode("ascii",errors="replace"))


def glyph(c,x,y,word,sx=1,sy=1,ink=BRIGHT,seed=0):
    for i,char in enumerate(word.upper()):
        for j,row in enumerate(FONT.get(char,FONT[" "])):
            for k,on in enumerate(row):
                if on=="1":
                    for dy in range(sy):
                        code=strbits(seed+i*79+j*13+k*31+dy,sx)
                        c.put(x+(i*6+k)*sx,y+j*sy+dy,code,ink if (i+k+j)%5 else VIOLET)


def centered_glyph(c,word,y,sy=2,seed=0):
    word=word.upper()[:17]
    sx=2 if (len(word)*6-1)*2<c.w-10 else 1
    glyph(c,(c.w-(len(word)*6-1)*sx)//2,y,word,sx,sy,seed=seed)


def legend(c,word,row=5,l=5,style=DIM):
    if word:
        c.put(l,row,word,style)


def points(c,s,fun,n=220,style=NORMAL):
    for i in range(n):
        x,y,v=fun(i/n,i)
        code="1" if hash16(s.seed+37*i)&1 else "0"
        c.put(x,y,code,style if v>0 else BLUE if v>-.45 else DEEP)


def curve(c,s,kind):
    if kind=="pulsewater":
        for j in range(4):
            p=j*.67
            for x in range(4,104):
                y=10+j*4+(1.8+s.bass*1.4)*math.sin(x*.15+s.t*2+p)
                v=math.exp(-((x-18-((s.age*24+j*7)%69))/4)**2)
                c.put(x,y-5*v,"01 "[int(x+j)%3],VIOLET if j==2 else BRIGHT if v>.5 else NORMAL if j==0 else BLUE)
        return
    n=420 if kind in ("surface","wavegrid") else 320
    def curve_point(u,i):
        t=s.t
        if kind in ("surface","wavegrid"):
            z=i%20
            x=(i//20-10)*2.6
            q=.52+1/(.95+z*.095)
            wave=math.sin(x*.135-z*.36-t*3.6)+.45*math.cos(z*.42+t*2)
            xx=54+x*q+math.sin(z*.3+t)*7
            yy=25-z*.98+wave*q*(1.5+s.bass*2.5)
            if kind=="wavegrid":
                xx,yy=54+(xx-54)*(.75+z*.02),16+(yy-15)*.8+(xx-54)*.09
            return xx,yy,.65-z*.061
        if kind in ("helix","current"):
            a=u*math.tau*4.2+s.t*3
            spread=(8 if kind=="helix" else 6) + 3*s.bass
            if kind=="helix":
                return 9+90*u,16+math.sin(a)*(spread*(.48+.52*math.sin(math.pi*u))),math.cos(a)
            return 8+93*u,19-7*u+math.sin(a+u*u*11)*spread*.68,math.cos(a)
        if kind=="moire":
            a=18*u+s.t*.9
            return 54+47*math.sin(a),16+10*math.sin(a*1.72+s.t*1.2),math.cos(a)
        return 5+97*u,16+8*math.sin(u*math.pi*2+s.t*3),math.cos(u*math.tau+s.t)
    points(c,s,curve_point,n,VIOLET if kind=="moire" else NORMAL)


def orbit(c,s,kind):
    def polar(u,i):
        a=u*math.tau
        if kind in ("whirlpool","drain"):
            a=a*6.3+s.t*2.5
            radius=42*(u if kind=="whirlpool" else u**1.9)*(1-.65*ease(s.phase) if kind=="drain" else 1)
            return (54+radius*math.cos(a),16+radius*.28*math.sin(a),math.cos(a))
        if kind in ("beacon","contact","radar"):
            band=i%7
            radius=5+band*(6 if kind=="radar" else 5)
            a=a*7+band*.44+s.t*.48
            rush=(a-s.t*4)%(math.tau)
            return (54+radius*math.cos(a),16+radius*.29*math.sin(a),
                    .75 if rush<.28 else -.30 if band<4 else -.8)
        band=i%6
        a=a*6+s.t*.55
        radius=13+band*5
        return (54+radius*math.cos(a)+4*math.sin(s.t+band),
                16+radius*.31*math.sin(a)*math.cos(band*.45+s.t*.17),math.sin(a))
    points(c,s,polar,385,VIOLET if kind in ("drain","whirlpool") else NORMAL)
    if kind in ("radar","contact","beacon"):
        c.put(53,16,"+",BRIGHT)
        a=s.t*3
        c.line(54,16,54+42*math.cos(a),16+12*math.sin(a),":",BLUE)
        if kind=="contact":
            c.put(76,9,"ACK=?",VIOLET)


def burst(c,s,kind):
    scale=.33+1.13*ease(s.phase)
    n=270 if kind!="slices" else 220
    for i in range(n):
        k=hash16(s.seed+79*i)
        a=(k%992)/992*math.tau
        d=((k>>7)%170)/170
        x=54+57*d*math.cos(a)*scale
        y=16+13*d*math.sin(a)*scale
        if kind=="breakfall":
            y+=7*s.phase*d
            x+=9*math.sin(2*a)
        elif kind=="starfield":
            x,y=54+(x-54)*1.16,16+(y-16)*1.24
        elif kind=="fracture":
            x=54+(x-54)*(1.35 if i%3==0 else .70)
            y=16+((y-16)*.70 if i%3 else (y-16)*1.25)
        elif kind=="slices":
            y=6+(i%16)
            x=(x+17*(i%4-1)*math.sin(10*s.age+i%5))%106
        tint=(VIOLET if i%13==0 else BRIGHT if i%22==0 else NORMAL if k%6<2 else BLUE)
        if i%17==0:
            c.put(x,y,strbits(k+int(s.t*5),4,"0123456789ABCDEF"),tint)
        else:
            c.put(x,y,"01:+."[k%5],tint)


def solid(c,s,shape):
    tick=s.t*.75
    if shape=="prism":
        corners=[(x,y,z) for z in (-1,1) for y in (-1,1) for x in (-1,1)]
        for i,(x,y,z) in enumerate(corners):
            for other in (i^1,i^2,i^4):
                if other<i: continue
                xx,yy,zz=corners[other]
                for j in range(24):
                    u=j/23
                    p=(x+(xx-x)*u,y+(yy-y)*u,z+(zz-z)*u)
                    a,b,d=project(p,tick)
                    c.put(a,b,"01"[j%2],VIOLET if d>0.2 else NORMAL)
        return
    for i in range(370):
        j,k=divmod(i,30)
        a=k/30*math.tau
        z=j/12-.5
        if shape=="lattice":
            q=(math.cos(a)*(1-abs(z)),z*2,math.sin(a)*(1-abs(z)))
        elif shape=="reflections":
            q=(math.cos(a)*.95,math.sin(a)*.70,z*1.6)
        else:
            q=(math.cos(a),math.sin(a),z)
        x,y,d=project(q,tick+.2*s.phase)
        c.put(x,y,"01"[k%2],BRIGHT if d>.7 else VIOLET if d>.2 else BLUE if d>-.3 else DEEP)
        if shape=="reflections":
            c.put(109-x,y,"." if k%3 else "0",BLUE)


def project(p,angle):
    x,y,z=p
    xx=x*math.cos(angle)+z*math.sin(angle)
    zz=-x*math.sin(angle)+z*math.cos(angle)
    depth=1/(1+.24*zz)
    return 54+xx*26*depth,16+(y+.17*zz)*8.8*depth,zz


def interface(c,s,kind):
    t=s.t
    token=s.seed+int(t*12)
    if kind in ("boot","reboot","overwrite"):
        lines={
            "boot":("> link(0, 1)","> mount /voice"),
            "reboot":("> reboot --recover","> retry(0x01)","> return: FAIL"),
            "overwrite":("> override(t)","t_old = read()","t_new = t_old & 0x00","> write(t_new)"),
        }[kind]
        for i,line in enumerate(lines):
            visible=max(0,int((s.age-i*.18)*34))
            c.put(8+6*i,9+4*i,line[:visible],VIOLET if "FAIL" in line else NORMAL)
        c.put(9,26,strbits(token,47,"0123456789ABCDEF"),BLUE)
        return
    if kind in ("archive","damage"):
        for block in range(3):
            x=4+block*35
            for row in range(8):
                y=6+row*3
                k=hash16(token//4+91*block+33*row)
                line=strbits(k,27,"0123456789ABCDEF")
                if kind=="damage" and (row+block+int(t*5))%5<2:
                    line=line[:11]+" CRC_FAIL"
                c.put(x,y,line,VIOLET if "FAIL" in line or row==block+int(t*2)%5 else BLUE if row%3 else DIM)
        return
    if kind in ("barrier","flood","sink","recovery","bookends"):
        if kind=="barrier":
            wall=62+round(9*math.sin(s.age*1.5))
            for y in range(5,29):
                c.put(wall,y,"||" if y%3 else "00",VIOLET)
                travel=min(wall-11,round(((s.age*34+y*3)%78)+4))
                c.put(travel,y,"0x01",NORMAL if y%3 else BRIGHT)
            legend(c,"RETURN E_NO_ROUTE",15,wall+7,VIOLET)
        elif kind in ("flood","sink"):
            level=24-round(17*ease(s.phase)) if kind=="flood" else 9+round(12*ease(s.phase))
            for y in range(5,29):
                surface=max(5,level+round(math.sin(y*.4+t*2)))
                for x in range(4,103,2):
                    yy=y+round(math.sin(x*.13+t*3)*1.8)
                    if yy>=surface and hash16(y*58+x*109+token//7)%5<=2:
                        c.put(x,yy,"01"[(x+y+token)%2],VIOLET if yy<surface+3 else BLUE)
            c.line(4,level,103,level,".",NORMAL)
            if kind=="sink":
                centered_glyph(c,"DROWN",min(20,level),1,token)
        elif kind=="bookends":
            delta=round(35*ease(s.phase))
            c.put(8+delta,12,"[ START",BRIGHT)
            c.put(85-delta,19,"END ]",VIOLET)
            c.line(16+delta,12,83-delta,19,":",BLUE)
        else:
            for i in range(47):
                k=hash16(s.seed+i*173)
                x=10+k%90
                y=6+(k//123)%21
                x=x+(54-x)*ease(s.phase)*.84
                y=y+(16-y)*ease(s.phase)*.70
                c.put(x,y,strbits(k,3,"01XY"),VIOLET if i%7==0 else BLUE)
            c.box(48,13,13,7,NORMAL)
            c.put(51,16,"READ",BRIGHT)
        return
    if kind in ("pair","zipper","tether","switches","routing"):
        if kind=="routing":
            SCENES["topology"](c,t,s.bass,s.phase)
            return
        if kind=="pair":
            move=round(22*ease(s.phase))
            glyph(c,20+move,11,"0",3,2,NORMAL,token)
            glyph(c,75-move,11,"1",3,2,VIOLET,token)
            c.line(36+move,16,74-move,16,":",BLUE)
        elif kind=="switches":
            for i in range(6):
                state=int((t*3+i*2)%7)<4
                x=9+i*16
                c.put(x,10,f"0x{i:X}",DIM)
                c.line(x,13,x,24,":",BLUE)
                c.put(x-2,14+(i+int(t*2))%10,"[1]" if state else "[0]",VIOLET if state else NORMAL)
        else:
            p=round(31*ease(s.phase)) if kind=="zipper" else round(13*ease(s.phase))
            for y in range(6,27,2):
                left=8+(y%7)+p
                right=82-(y%8)-p
                c.put(left,y,strbits(token+y*7,12),NORMAL if y%4 else BRIGHT)
                c.put(right,y,strbits(token+y*13,12),VIOLET if y%4 else BLUE)
            c.line(left+8,15,right-1,15,"." if kind=="tether" else ":",BLUE)
        return
    if kind=="clock":
        for i in range(47):
            a=math.tau*i/47
            c.put(33+23*math.cos(a),16+10*math.sin(a),"0" if i%4 else "1",BLUE)
        a=t*3.2
        c.line(33,16,33+18*math.cos(a),16+7*math.sin(a),":",BRIGHT)
        c.put(62,14,f"{int(s.phase*1000):04d} ms",VIOLET)


def lyric_field(c,s,new,old=None,departure=False):
    phrase=new.upper().strip()
    if not phrase:
        phrase=s.word
    if not phrase:
        return
    raw=cipher(phrase)+"  "
    lexical=" | "+phrase+" | "
    pace=int(s.t*14)
    for row in range(5,29):
        fragment=(raw if row%4 else lexical)*8
        at=(row*19+pace*(1 if row%2 else -1))%(len(fragment)//2)
        x=2+(row%3)
        c.put(x,row,fragment[at:at+104],BLUE if row%4 else DIM)
    blocks=[]
    for word in phrase.split():
        if not blocks or len(blocks[-1])+len(word)>26:
            blocks.append(word)
        else:
            blocks[-1]+=" "+word
    # Wide readable source line across a moving hexadecimal background.
    if len(blocks)>3:
        blocks=[" ".join(phrase.split()[:5])," ".join(phrase.split()[5:])]
    for i,line in enumerate(blocks):
        y=13+i*3
        c.put(5,y," "*98,DEEP)
        c.center(y,line,WHITE if i==0 else BRIGHT)
    headline=s.word if s.word and len(s.word)<=16 else max(phrase.split(),key=len,default="SYNC")
    for y in range(20,28):
        c.put(8,y," "*93,DEEP)
    centered_glyph(c,headline,20,1,s.seed+pace)
    if old and (s.age<.24 or departure):
        offset=hash16(s.seed+pace)%16-8
        c.put(max(2,7+offset),10,"// "+old.upper()[:92],VIOLET)


def draw_scene(c,s,kind,words,previous=None,departure=False):
    if kind in ("lyric","typewall","field"):
        lyric_field(c,s,words,previous,departure)
    elif kind=="title":
        for y in range(6,29,3):
            c.put(5,y,strbits(s.seed+y+int(s.t*4),98,"01 ."),BLUE)
        centered_glyph(c,"CYBERNETIC",10,3,s.seed+int(s.t*15))
    elif kind in ("surface","wavegrid","current","helix","moire","pulsewater"):
        curve(c,s,kind)
    elif kind in ("orbit","radar","beacon","contact","whirlpool","drain"):
        orbit(c,s,kind)
    elif kind in ("slices","fracture","breakfall","starfield"):
        burst(c,s,kind)
    elif kind in ("prism","lattice","reflections"):
        solid(c,s,kind)
    elif kind in ("queue","memory","collapse","gate","tunnel"):
        SCENES["portal" if kind=="tunnel" else kind](c,s.t,s.bass,s.phase)
    else:
        interface(c,s,kind)
