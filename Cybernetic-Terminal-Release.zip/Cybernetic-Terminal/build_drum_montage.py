"""Build the 52-second montage atlas from the included character references."""
from base64 import b64encode
import gzip
import json
from math import cos, sin, tau
from pathlib import Path
from random import Random

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageOps

from drum_montage import BEATS, SHADES, TONES


MEDIA = Path(__file__).resolve().parent / "media"
SIZE = (848, 480)
GRID = (240, 96)
RESAMPLE = Image.Resampling.LANCZOS


def load(path):
    with Image.open(path) as image:
        return image.convert("RGBA")


def crop(image, box):
    w, h = image.size
    x0, y0, x1, y1 = box
    return image.crop((round(w * x0), round(h * y0), round(w * x1), round(h * y1)))


def grade(image, family, mix=.58):
    rgb = image.convert("RGB")
    light = ImageOps.autocontrast(ImageOps.grayscale(rgb), cutoff=.55)
    tone = TONES[family]
    palette = ImageOps.colorize(light, (8, 6, 13), tone, tuple(round(v * .61) for v in tone))
    result = Image.blend(rgb, palette, mix)
    return ImageEnhance.Contrast(result).enhance(1.13)


def bleed(image, family, *, box=None, center=(.5, .5), mix=.55):
    if box is not None:
        image = crop(image, box)
    image = ImageOps.fit(image, SIZE, RESAMPLE, centering=center)
    return grade(image, family, mix)


def backdrop(family, pattern):
    w, h = SIZE
    rgb = TONES[family]
    dark = tuple(round(v * .25) for v in rgb)
    light = tuple(round(v * .57) for v in rgb)
    base = tuple(round(v * .083) for v in rgb)
    result = Image.new("RGB", SIZE, base)
    draw = ImageDraw.Draw(result)
    if pattern == "circuit":
        for lane in range(10):
            y = 12 + lane * 51
            inner = 245 + (lane * 67) % 180
            for flip in (False, True):
                x = w - 1 - inner if flip else inner
                end = w - 34 if flip else 34
                elbow = x + (52 if flip else -52)
                draw.line([(end, y), (elbow, y), (x, y + 36), (w // 2, y + 36)], dark, 5)
                draw.ellipse((end - 5, y - 5, end + 5, y + 5), outline=light, width=2)
                rail = end + (18 if flip else -18)
                draw.line((rail, y - 9, rail, y + 12), light, 3)
    elif pattern == "radial":
        for r in range(52, 600, 31):
            bounds = (w // 2 - r, h // 2 - r, w // 2 + r, h // 2 + r)
            for turn in range(0, 360, 60):
                start = turn + r % 21
                draw.arc(bounds, start, start + 40, fill=light if r % 4 == 0 else dark, width=5)
        for k in range(18):
            a = k * tau / 18
            draw.line((w / 2 + 120 * cos(a), h / 2 + 120 * sin(a),
                       w / 2 + 575 * cos(a), h / 2 + 575 * sin(a)), dark, 3)
    elif pattern == "petal":
        for k in range(9):
            angle = k * tau / 9
            cx = w * .50 + 205 * cos(angle)
            cy = h * .48 + 174 * sin(angle)
            for r in (33, 61, 98, 133):
                draw.arc((cx - r, cy - r, cx + r, cy + r), k * 40, k * 40 + 218,
                         fill=light if r % 2 else dark, width=5)
    else:
        for i in range(-6, 15):
            x = i * 82 + 9
            draw.line((x, 0, x - 300, h), dark, 18)
            draw.line((x + 27, 0, x - 273, h), light, 2)
    noise = Random(3211 + family * 101 + len(pattern) * 37)
    for k in range(400):
        x, y = noise.randrange(w), noise.randrange(h)
        span = 3 + k % 11
        draw.line((x, y, x + span, y), light if k % 7 == 0 else dark, 3)
    return result


def cutout(scene, image, family, x, y, height):
    width = round(image.width * height / image.height)
    art = image.resize((width, height), RESAMPLE)
    mask = art.getchannel("A")
    art = grade(art, family)
    scene.paste(art, (x - width // 2, y), mask)
    return scene


def portrait_plate(image, family):
    scene = backdrop(family, "circuit")
    height = SIZE[1]
    w = round(image.width * height / image.height)
    art = image.resize((w, height), RESAMPLE)
    art = grade(art, family, .46)
    values = np.clip(np.minimum(np.arange(w), np.arange(w)[::-1]) * 255 / 38, 0, 255)
    alpha = Image.fromarray(np.tile(values.astype(np.uint8), (height, 1)))
    scene.paste(art, ((SIZE[0] - w) // 2, 0), alpha)
    return scene


def splice(left, right, split, fade=8):
    w, h = SIZE
    x = np.arange(w)[None, :]
    y = np.arange(h)[:, None]
    boundary = split * w + (y - h * .5) * .46
    values = np.uint8(np.clip((boundary - x) * 255 / fade + 128, 0, 255))
    return Image.composite(left, right, Image.fromarray(values))


def triptych(pictures):
    result = Image.new("RGB", SIZE)
    draw = ImageDraw.Draw(result)
    panel_width = SIZE[0] // 3
    for i, (image, tone, zoom) in enumerate(pictures):
        left = i * panel_width
        face = ImageOps.fit(crop(image, zoom), (panel_width + 1, SIZE[1]), RESAMPLE)
        result.paste(grade(face, tone, .93), (left, 0))
        if i:
            draw.line((left, 0, left, SIZE[1]), fill=TONES[tone], width=3)
    return result


def reticle(scene, family):
    draw = ImageDraw.Draw(scene)
    w, h = SIZE
    for x, y in ((110, 63), (w - 110, h - 65)):
        for d in (-1, 1):
            draw.line((x + d * 18, y, x + d * 76, y), TONES[family], 2)
            draw.line((x, y + d * 12, x, y + d * 35), TONES[family], 2)
    return scene


def shards(a, b):
    w, h = SIZE
    result = backdrop(5, "stripes")
    for i in range(7):
        mask = Image.new("L", SIZE)
        x = i * (w // 6)
        u = 36 + (i * 17) % 46
        ImageDraw.Draw(mask).polygon(((x - 63, 0), (x + u, 0), (x - 8, h), (x - 137, h)), fill=255)
        result.paste(a if i % 2 == 0 else b, (0, 0), mask)
    return result


def montage():
    refs = [load(MEDIA / "drum-sources" / f"reference-{n}.jpg") for n in range(1, 8)]
    old = [load(MEDIA / "portraits" / f"portrait-{n}.png") for n in range(1, 6)]
    mask = load(MEDIA / "portraits" / "glitch-portrait.png")
    maid, surprise, open_mouth, fangs, glare, flower, peace = refs

    yield bleed(surprise, 2, center=(.43, .58), mix=.50)
    yield portrait_plate(maid, 3)
    yield bleed(peace, 4, center=(.68, .50), mix=.47)
    yield bleed(flower, 5, mix=.40)
    yield bleed(glare, 6, box=(.04, .05, .98, .96), mix=.52)
    yield cutout(backdrop(3, "petal"), old[0], 3, 498, -98, 641)
    yield bleed(open_mouth, 1, mix=.64)
    yield bleed(fangs, 2, box=(.04, .04, .98, .99), mix=.61)

    iris = bleed(glare, 7, box=(.16, .17, .60, .64), mix=.83)
    yield reticle(iris, 6)
    paired = cutout(backdrop(1, "radial"), old[1], 1, 212, -39, 590)
    yield cutout(paired, ImageOps.mirror(old[4]), 2, 652, -25, 548)
    yield cutout(backdrop(5, "petal"), old[2], 4, 378, -130, 677)
    yield triptych(((surprise, 3, (.19, .24, .67, .99)),
                    (maid, 1, (.06, .13, .95, .89)),
                    (flower, 5, (.33, .04, .76, .90))))
    yield cutout(backdrop(7, "stripes"), old[3], 7, 590, -129, 702)
    a = bleed(maid, 3, box=(.03, .09, .91, .94), mix=.87)
    b = bleed(flower, 5, box=(.41, .23, .83, .86), mix=.84)
    yield splice(a, b, .43)
    yield cutout(backdrop(2, "radial"), old[4], 2, 293, -116, 676)
    wink = bleed(peace, 6, box=(.36, .04, .95, .76), mix=.87)
    yield reticle(wink, 4)
    yield cutout(backdrop(1, "circuit"), crop(mask, (.20, .11, .77, .82)), 1, 386, -54, 620)
    yield triptych(((open_mouth, 7, (.17, .18, .85, .93)),
                    (fangs, 2, (.21, .14, .91, .88)),
                    (glare, 4, (.20, .24, .91, .93))))
    yield shards(bleed(flower, 5, mix=.91), bleed(open_mouth, 3, mix=.94))
    yield cutout(backdrop(5, "radial"), mask, 5, 424, -163, 765)


def encode(image):
    rgb = image.resize(GRID, RESAMPLE)
    hsv = np.asarray(rgb.convert("HSV"))
    hue, sat = hsv[:, :, 0], hsv[:, :, 1]
    # Warm tones retain their accents; neutral skin and highlights stay pale.
    family = np.asarray([5, 4, 6, 6, 7, 7, 1, 1, 1, 3, 3, 3, 2, 2, 2, 5])[hue // 16]
    family = np.where(sat < 32, 0, family)
    raw = rgb.convert("L")
    luma = np.asarray(raw, dtype=np.float32) / 255
    softened = np.asarray(raw.filter(ImageFilter.GaussianBlur(.9)), dtype=np.float32) / 255
    ridge = luma - softened
    shade = np.power(np.clip(luma * 1.19 + ridge * .62, 0, 1), .74) * (SHADES - 1)
    edge = np.abs(ridge) > .075
    cells = (family * SHADES + np.rint(shade) + edge * 128).astype(np.uint8)
    return b64encode(cells.tobytes()).decode("ascii")


def main():
    frames = [encode(image) for image in montage()]
    if len(frames) != len(BEATS):
        raise ValueError("Expected one character image per drum cut")
    payload = json.dumps({"grid": GRID, "frames": frames}, separators=(",", ":")).encode("utf-8")
    (MEDIA / "drum-montage.json.gz").write_bytes(gzip.compress(payload, mtime=0))
    print(f"{len(frames)} character images at {GRID[0]} × {GRID[1]} cells")


if __name__ == "__main__":
    main()
