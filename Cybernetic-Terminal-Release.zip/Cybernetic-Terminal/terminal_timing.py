"""Shared time marks and character-only ending sequence."""
from bisect import bisect_right
import math

from cybernetic import ease, hash16
from player import BRIGHT, NORMAL, WHITE, Canvas
from visual_variation import BEATS, BLUE, DEEP, VIOLET, clamp


GRID = (108, 38)
LYRIC_DELAY = 1.5

CHORUSES = ((58.71, 71.77), (151.22, 179.75))
IDLE_START = 170.0
OUTRO = 179.75
ZERO = 196.96
POWER_OFF = 197.18
BLACK = 197.77
PORTRAIT_TIMES = (
    1.90, 6.45, 59.85, 62.28, 62.80, 65.47, 65.92, 69.56, 70.08,
    151.22, 154.17, 158.26, 161.90, 168.72, 174.17, 176.44, 183.73, 189.18,
)
ARTIFACT_BEATS = tuple(sorted(set(BEATS + PORTRAIT_TIMES + (
    22.44, 30.99, 34.63, 34.99, 38.62, 41.63, 42.58, 45.08, 48.84,
    50.53, 52.35, 54.18, 57.80, 58.49, 58.71, 58.94, 59.52,
    61.38, 62.28, 62.80, 64.61, 65.47, 65.92, 68.65, 69.56, 70.08,
    72.74, 76.82, 80.46, 84.62, 87.73, 115.31, 121.45, 130.99,
    159.17, 163.26, 164.63, 169.17, 170.07, 173.71, 174.62, 175.99, 179.17,
))))
OUTRO_COLORS = {
    7: (42, 150, 179), 8: (138, 103, 208), 9: (205, 112, 122),
    10: (212, 168, 87), 11: (102, 188, 145), 12: (103, 136, 227),
}

def pulse_canvas(time):
    w,h=GRID
    c=Canvas(w,h)
    progress=clamp((ZERO-time)/(ZERO-OUTRO))
    elapsed=max(0,time-OUTRO)
    count=math.ceil(progress*100-1e-8)
    fill=(1-progress)**1.56
    for y in range(1,h-1):
        for x in range(2,w-2):
            p=hash16(x*197+y*331+1103)/65535
            if p < fill:
                value=hash16(x*175+y*33+int(elapsed*8)*517)
                c.put(x,y,"0123456789ABCDEF"[value&15],7+(value>>4)%6)

    left,right,mid=11,w-12,16
    # Keep a narrow window for the last pulse and the countdown.
    edge=max(2,round(6*(1-ease((elapsed-6)/10))))
    for row in range(mid-edge,mid+edge+1):
        c.put(left-1,row," "*(right-left+3),DEEP)
    c.put(left,mid-7,"PULSE / SIGNAL",BLUE)
    previous=None
    for x in range(left,right+1):
        dt=(right-x)/(right-left)*3.0
        v=piano_pulse(elapsed-dt)
        y=mid-v
        mode=NORMAL if abs(v)>.2 else BLUE
        if previous is not None:
            c.line(x-1,previous,x,y,"0" if abs(v)>.22 else ".",mode)
        previous=y
    c.put(right,previous,"+",VIOLET if elapsed>11 else BRIGHT)
    bar_y,bar_left,bar_w=26,18,63
    start=bar_left-2
    for row in (bar_y-1,bar_y,bar_y+1):
        c.put(start,row," "*(bar_w+14),DEEP)
    amount=round(progress*bar_w)
    c.put(bar_left,bar_y,"["+"1"*amount+"."*(bar_w-amount)+"]",NORMAL if count>23 else VIOLET)
    c.put(bar_left+bar_w+5,bar_y,f"{count:3d}%",WHITE)
    return c


# Spectral attack peaks from the supplied recording, in source seconds.
PIANO_KEYS = (180.405,181.895,183.710,185.525,187.345,189.165,190.985,192.800)
PIANO_REL = tuple(t-OUTRO for t in PIANO_KEYS)
def piano_pulse(elapsed):
    i=bisect_right(PIANO_REL,elapsed)-1
    if i<0:
        return 0
    age=elapsed-PIANO_REL[i]
    if age>.45:
        return 0
    # The rightmost point lifts on the attack rather than anticipating it.
    peak=6.3*(1-.83*i/(len(PIANO_REL)-1))
    return peak*(math.exp(-(age/.060)**2)
                 -.29*math.exp(-((age-.105)/.041)**2)
                 +.18*math.exp(-((age-.247)/.075)**2))

