"""Secondary terminal graphics drawn into unused cells around the main scene."""
from math import sin, tau

from cybernetic import hash16
from player import NORMAL
from visual_variation import BLUE, DEEP, VIOLET


class DetailField:
    def __init__(self, canvas, bounds):
        self.canvas = canvas
        self.left, self.top, self.right, self.bottom = bounds

    def cell(self, x, y):
        return (self.left + round((self.right - self.left) * x),
                self.top + round((self.bottom - self.top) * y))

    def put(self, x, y, text, ink):
        if not self.top <= y <= self.bottom:
            return
        row = self.canvas.cells[y]
        for i, char in enumerate(text, x):
            if self.left <= i <= self.right and char != " " and row[i][0] == " ":
                row[i] = (char, ink)

    def mark(self, x, y, text, ink=BLUE):
        col, row = self.cell(x, y)
        self.put(col, row, text, ink)

    def trace(self, points, ink=BLUE):
        # Orthogonal tracks with a pad at both ends.
        cells = [self.cell(*point) for point in points]
        for (x, y), (end_x, end_y) in zip(cells, cells[1:]):
            if x == end_x:
                for row in range(min(y, end_y) + 1, max(y, end_y)):
                    self.put(x, row, ":", ink)
            else:
                start, end = sorted((x, end_x))
                self.put(start + 1, y, "─" * (end - start - 1), ink)
        for i, (x, y) in enumerate(cells):
            self.put(x, y, "o" if i in (0, len(cells) - 1) else "+", ink)

    def meter(self, x, y, bands, time, ink=BLUE, length=12):
        col, row = self.cell(x, y)
        head = int(time * 10) % length
        for i in range(length):
            value = bands[i * len(bands) // length]
            # The scanning cell still moves on a quiet band.
            char = "█" if i == head else "▓" if value > .63 else "▒" if value > .36 else "·"
            self.put(col + i, row, char, ink if i == head or value > .63 else DEEP)

    def contacts(self, x, y, count, time, ink):
        col, row = self.cell(x, y)
        pulse = int(time * 13) % count
        for i in range(count):
            a = col + i * 3
            self.put(a, row - 1, "╷", BLUE)
            self.put(a, row, "▓▒" if i == pulse else "░░", ink if i == pulse else BLUE)
            self.put(a + 1, row + 1, "╵", DEEP)


WAVE_MODES = {"wave", "undertow", "flood", "sink", "current"}


def paint_board_details(canvas, bounds, mode, index, age, time, bass, bands):
    field = DetailField(canvas, bounds)
    accent = VIOLET if bass > .39 else BLUE

    if mode == "power":
        for y in (.15, .76):
            field.trace(((.04, y), (.19, y), (.19, y + .10), (.28, y + .10)))
            field.trace(((.96, y + .10), (.81, y + .10), (.81, y), (.72, y)), accent)
        field.mark(.07, .06, "CLK", NORMAL)
        field.contacts(.08, .61, 3 if canvas.w < 80 else 5, time, accent)
        field.contacts(.80, .51, 3 if canvas.w < 80 else 5, -time, NORMAL)
        for offset in range(5):
            col = .74 + offset * .05
            field.mark(col, .91, "◦" if (int(time * 11) + offset) % 5 else "◆", accent)
    elif mode == "hold":
        # Route a secondary circuit above and below the original signal lines.
        for lane in range(2):
            top = .09 + lane * .08
            step = .24 + lane * .13
            field.trace(((.065, top), (step, top), (step, top + .10), (.69, top + .10)),
                        BLUE if lane else DEEP)
            field.trace(((.94, 1 - top), (1 - step, 1 - top), (1 - step, .90 - top),
                         (.31, .90 - top)), accent if lane else DEEP)
            field.mark(.085 + (time * .46 + lane * .18) % .49, top - .05, "›", NORMAL)
        field.mark(.09, .88, "· · ·", accent)
        field.mark(.85, .27, "[I/O]", BLUE)
        field.meter(.73, .06, bands, time, accent, 8)
    elif mode in WAVE_MODES:
        for lane, center in enumerate((.17, .76)):
            for i in range(34):
                x = .045 + .91 * i / 33
                band = bands[(i + lane * 6) % len(bands)]
                y = center + (.035 + .105 * band) * sin(tau * (x * 2.6 - time * .96 + lane * .26))
                mark = "·" if i % 5 else ":" if (i + int(time * 14)) % 9 else "◆"
                field.mark(x, y, mark, NORMAL if mark == "◆" else BLUE if lane else accent)
        field.meter(.075, .08, bands, time, accent, 8)
        field.mark(.84, .91, "╵╵╵", BLUE)
    elif mode == "scan":
        for i in range(13):
            seed = hash16(index * 941 + 653 * i)
            side = -1 if i % 2 else 1
            x = .5 + side * (.25 + .22 * (seed % 47) / 46)
            y = .09 + .81 * ((seed >> 6) % 43) / 42
            live = (time * .82 + (seed % 19) / 19) % 1 < .16
            field.mark(x, y, "◇" if live else "·", NORMAL if live else BLUE)
        field.trace(((.04, .29), (.04, .13), (.22, .13)), DEEP)
        field.trace(((.95, .68), (.95, .85), (.79, .85)), BLUE)
        field.meter(.075, .88, bands, -time, accent, 8)
        for i in range(5):
            field.mark(.89, .2 + .064 * i, "▪" if i == int(time * 8) % 5 else ":", accent)
    elif mode == "title":
        field.trace(((.025, .23), (.085, .23), (.085, .11), (.22, .11)), BLUE)
        field.trace(((.97, .77), (.91, .77), (.91, .89), (.78, .89)), accent)
        field.meter(.04, .84, bands, time, BLUE, 9)
        field.meter(.87, .13, bands[4:], -time, accent, 7)
    elif mode in {"fault", "bits", "gate"}:
        for i in range(8):
            seed = hash16(index * 971 + i * 607)
            x = .04 + ((seed % 71) / 70) * .86
            y = .14 + ((seed >> 7) % 19) * .041
            slid = max(0.0, min(.91, x + (.025 if i % 2 else -.02) * (int(age * 16) % 5)))
            text = "╱╱" if i % 3 else f"{seed >> 8:02X}"
            field.mark(slid, y, text, accent if i % 3 == 0 else BLUE)

    # Mount points and perforations are steady between cuts. Only the signal moves.
    for i in range(36):
        seed = hash16(i * 343 + index * 77)
        offset = (seed % 29) / 28
        x = .015 + .26 * offset if i % 2 else .70 + .29 * offset
        y = .07 + .86 * ((seed // 29 % 37) / 36)
        field.mark(x, y, "+" if i % 7 == 0 else "·", BLUE if i % 7 == 0 else DEEP)


def stage_field(canvas, top=3, bottom_margin=8):
    return DetailField(canvas, (2, top, canvas.w - 3, canvas.h - bottom_margin))


def paint_later_details(canvas, time, mode, kind, bands, attack):
    field = stage_field(canvas)
    active = NORMAL if attack > .42 else BLUE
    accent = VIOLET if attack > .42 else DEEP
    tick = int(time * 10)
    if mode == "current":
        # Broken tide gauges sit in the gap between the logs and the tunnel.
        for i in range(10):
            y = .08 + i * .086
            mark = "╞═" if i % 3 == 0 else "·"
            field.mark(.16, y, mark, active if i == tick % 10 else BLUE)
            field.mark(.79, 1 - y, "═╡" if i % 3 == 0 else "·", accent)
        field.meter(.28, .02, bands, time, active, 16)
        field.meter(.65, .94, bands[4:], -time, VIOLET, 9)
    elif mode == "fault":
        for i in range(6):
            offset = i * .032
            y = .12 + ((i + int(time * 11)) % 7) * .11
            field.mark(.02 + offset, y, "╶┈" if i % 2 else "╲", BLUE)
            field.mark(.87 + offset * .4, 1 - y, "╱" if i % 2 else "┈╴", VIOLET)
        field.meter(.06, .92, bands, time, active, 8)
    elif mode == "pressure":
        field.trace(((.04, .22), (.14, .22), (.14, .41), (.22, .41)), BLUE)
        field.trace(((.96, .78), (.86, .78), (.86, .59), (.78, .59)), VIOLET)
        for i in range(8):
            x = .05 + i * .041
            field.mark(x, .13, "│" if i % 3 else "╷", active)
            field.mark(1 - x, .89, "▰" if i < round(attack * 8) else "·", accent)
        field.contacts(.045, .74, 4, time, active)
        field.contacts(.79, .26, 4, -time, VIOLET)
    elif mode == "controls":
        # The pre-chorus already has moving devices. Add edge contacts and a strike indicator.
        for i in range(9):
            x = .06 + .11 * i
            live = (tick + i) % 9 == 0 or i < attack * 6
            field.mark(x, .05, "╤" if live else "┬", active if live else BLUE)
            field.mark(x, .95, "╧" if live else "┴", VIOLET if live else DEEP)
        field.meter(.03, .82, bands, -time, active, 8)
        field.meter(.82, .17, bands[4:], time, VIOLET, 8)
    elif mode == "climax":
        # Keep clear of the headline box even in a short console.
        field = DetailField(canvas, (3, 2, canvas.w - 4, 2))
        field.meter(.02, 0, bands, time, active, 13)
        field.meter(.75, 0, bands[3:], -time, VIOLET, 11)
        if canvas.h >= 28:
            row = canvas.h - 7
            field = DetailField(canvas, (3, row, canvas.w - 4, row))
            field.mark(.11, 0, "└─··", BLUE)
            field.mark(.83, 0, "··─┘", accent)
    else:
        if kind in {"prism", "lattice", "moire", "reflections", "surface", "flood", "current", "drain"}:
            for i in range(11):
                x = .035 + .018 * i
                y = .18 + .22 * sin(tau * (i / 15 - time * .43))
                field.mark(x, .33 + y, "·" if i % 3 else "+", active)
                field.mark(1 - x, .72 - y, ":" if i % 3 else "·", accent)
        else:
            field.trace(((.03, .15), (.155, .15), (.155, .31), (.22, .31)), BLUE)
            field.trace(((.97, .83), (.84, .83), (.84, .69), (.78, .69)), accent)
            field.mark(.035, .19, "+" if attack > .5 else "·", active)
        field.contacts(.04, .88, 3, time, VIOLET)
        field.meter(.80, .07, bands[5:], -time, active, 9)


def paint_ecg_details(canvas, phase, attack):
    if phase >= .85:
        return
    field = stage_field(canvas, top=2, bottom_margin=5)
    for i in range(13):
        x = .055 + i * .074
        field.mark(x, .09, "╷" if i % 3 == 0 else "·", BLUE if i % 3 == 0 else DEEP)
        field.mark(x, .92, "╵" if i % 3 == 0 else "·", DEEP)
    for x in (.035, .95):
        for i in range(5):
            field.mark(x, .32 + .072 * i, "┤" if x < .5 else "├",
                       NORMAL if attack > .18 and i == 2 else BLUE)
