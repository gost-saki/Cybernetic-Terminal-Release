"""Bake audio timing, spectrum and character portraits for the terminal."""
from pathlib import Path
import gzip
import json
import math
from random import Random
import wave

import numpy as np
from PIL import Image

from opening_analysis import opening_cuts
from recut_scenes import SHOTS
from terminal_art import sparse_hits
from terminal_stage import SOLOS
from terminal_timing import ARTIFACT_BEATS, PORTRAIT_TIMES
from visual_variation import FPS, lyric_entries


ROOT = Path(__file__).resolve().parent
MEDIA = ROOT / "media"


def audio_peaks(path):
    """Return a short-hop onset trace from the same PCM used for the final video."""
    with wave.open(str(path),"rb") as wav:
        sr=wav.getframerate()
        pcm=np.frombuffer(wav.readframes(wav.getnframes()),dtype="<i2")
        samples=pcm.reshape(-1,wav.getnchannels()).astype(np.float32).mean(1)/32768
    hop=max(1,round(sr*.005))
    size=round(sr*.024)
    pad=np.pad(samples,(size//2,size//2))
    signal=np.lib.stride_tricks.sliding_window_view(pad,size)[::hop]
    window=np.hanning(size)
    bins=np.fft.rfftfreq(size,1/sr)
    values=[]
    for i in range(0,len(signal),600):
        spectrum=np.abs(np.fft.rfft(signal[i:i+600]*window,axis=1))/window.sum()
        values.append(np.log1p(550*spectrum[:,(bins>80)&(bins<7650)]))
    logs=np.concatenate(values,axis=0)
    change=np.maximum(logs[2:]-logs[:-2],0)
    flux=np.pad(np.mean(change,axis=1),(2,0))
    return flux,hop/sr


def aligned_time(time,flux,hop,tolerance=.088):
    center=round(time/hop)
    reach=round(tolerance/hop)
    hits=list(range(max(2,center-reach),min(len(flux)-2,center+reach+1)))
    if not hits:
        return time
    background=float(np.quantile(flux[max(0,center-68):min(len(flux),center+68)],.60))
    selected=max(hits,key=lambda i:flux[i]*(1-.48*abs(i-center)/max(1,reach)))
    return selected*hop if flux[selected]>max(.025,background*1.53) else time


def analyze(wav_path):
    with wave.open(str(wav_path),"rb") as stream:
        sample_rate=stream.getframerate()
        data=np.frombuffer(stream.readframes(stream.getnframes()),dtype="<i2")
        samples=data.reshape(-1,stream.getnchannels()).astype(np.float32).mean(1)/32768
        duration=stream.getnframes()/sample_rate
    size=2048
    pad=np.pad(samples,(size//2,size//2))
    window=np.hanning(size)
    freqs=np.fft.rfftfreq(size,1/sample_rate)
    bounds=np.searchsorted(freqs,np.geomspace(54.,10200.,49))
    levels=[]
    for frame in range(math.ceil(duration*FPS)):
        offset=round(frame*sample_rate/FPS)
        gains=np.abs(np.fft.rfft(pad[offset:offset+size]*window))/size
        levels.append([gains[a:max(a+1,b)].max() for a,b in zip(bounds,bounds[1:])])
    levels=np.asarray(levels)
    return np.clip((levels/np.maximum(np.percentile(levels,97,axis=0),.0014))**.63,0,1)


def drum_hits(path):
    """Detect percussive low-end attacks from the same PCM used for the movie."""
    with wave.open(str(path), "rb") as audio:
        sample_rate = audio.getframerate()
        pcm = np.frombuffer(audio.readframes(audio.getnframes()), dtype="<i2")
        samples = pcm.reshape(-1, audio.getnchannels()).astype(np.float32).mean(1) / 32768
    size, hop = 2048, round(sample_rate / 100)
    windows = np.lib.stride_tricks.sliding_window_view(np.pad(samples, size // 2), size)[::hop]
    weights = np.hanning(size)
    frequency = np.fft.rfftfreq(size, 1 / sample_rate)
    mask = (frequency >= 42) & (frequency < 190)
    low_spectrum = np.concatenate([
        np.abs(np.fft.rfft(windows[i:i + 500] * weights, axis=1))[:, mask]
        for i in range(0, len(windows), 500)
    ])
    envelope = np.log1p(low_spectrum)
    rise = np.pad(np.maximum(envelope[3:] - envelope[:-3], 0).mean(axis=1), (3, 0))
    threshold = max(.11, np.quantile(rise, .88))
    radius = 9
    picks = []
    for i in range(radius, len(rise) - radius):
        if rise[i] < threshold or i != i - radius + rise[i - radius:i + radius + 1].argmax():
            continue
        if picks and i - picks[-1] < 18:
            if rise[i] > rise[picks[-1]]:
                picks[-1] = i
        else:
            picks.append(i)
    return tuple(round(i * hop / sample_rate, 3) for i in picks)


def portrait_grid(image, dimensions, *, opaque_mask=False):
    pixels = np.asarray(image.convert("RGBA").resize(dimensions, Image.Resampling.BOX), dtype=np.int16)
    rgb = pixels[:, :, :3]
    alpha = pixels[:, :, 3] / 255
    light = np.dot(rgb, (.23, .70, .07)) * alpha
    shade = np.maximum(0, light - 23) / (255 - 23)
    level = np.ceil(shade ** .88 * 7).astype(int)
    cool = (rgb[:, :, 2] - rgb[:, :, 1]) > 26
    value = level + 8 * (cool & (level > 0))
    if opaque_mask:
        value = np.where(alpha >= .44, value | 16, 0)
    return ["".join(chr(65 + x) for x in row) for row in value]


def special_portrait(path):
    with Image.open(path) as source:
        w, h = source.size
        crop = (round(.175 * w), round(.225 * h), round(.83 * w), round(.80 * h))
        return portrait_grid(source.crop(crop), (148, 72))


def shuffled_indices(randomizer, count):
    previous = None
    while True:
        choices = list(range(count))
        randomizer.shuffle(choices)
        if count > 1 and previous == choices[0]:
            choices[0], choices[1] = choices[1], choices[0]
        yield from choices
        previous = choices[-1]


def timings(wav):
    flux, hop = audio_peaks(wav)
    lyric_anchors = {time for time, _ in lyric_entries(MEDIA / "Cybernetic.lrc")}
    locked = lyric_anchors | {0, 58.71, 71.77, 91.50, 150.44, 151.22}
    cuts = [shot.start if shot.start in locked else aligned_time(shot.start, flux, hop)
            for shot in SHOTS]
    if not all(a < b for a, b in zip(cuts, cuts[1:])):
        raise ValueError("Audio alignment moved a cut past its neighbor")
    triggers = sorted(at if at in locked else aligned_time(at, flux, hop, .055)
                      for at in ARTIFACT_BEATS)
    return cuts, triggers


def build(wav):
    paths = sorted((MEDIA / "portraits").glob("portrait-*.png"))
    if len(paths) != 5:
        raise ValueError("The character sequence expects five source portraits")
    cuts, triggers = timings(wav)
    images = shuffled_indices(Random(9241), len(paths))
    regions = shuffled_indices(Random(4837), 4)
    events = [(at, next(images), next(regions), bool(i % 2))
              for i, at in enumerate(PORTRAIT_TIMES)]

    portraits = []
    flashes = []
    for path in paths:
        with Image.open(path) as source:
            portraits.append(portrait_grid(source, (76, 76)))
        flashes.append(special_portrait(path))

    solos = {}
    for shot, (portrait, (mx, my), start) in SOLOS.items():
        with Image.open(paths[portrait]) as source:
            top, bottom = round(source.height * start), round(source.height * .91)
            solos[str(shot)] = {
                "map": portrait_grid(source.crop((0, top, source.width, bottom)), (132, 68)),
                "mouth": (mx / source.width, (my - top) / (bottom - top)),
            }

    reference = MEDIA / "portraits" / "glitch-portrait.png"
    special = special_portrait(reference)
    with Image.open(reference) as source:
        width, height = source.size
        upper_body = source.crop((round(.08 * width), 0, round(.93 * width), round(.87 * height)))
        idle_portrait = portrait_grid(upper_body, (156, 128), opaque_mask=True)

    with wave.open(str(wav), "rb") as audio:
        duration = audio.getnframes() / audio.getframerate()
    data = {
        "duration": duration,
        "shot_times": cuts,
        "opening_cues": opening_cuts(wav),
        "trigger_times": triggers,
        "green": sparse_hits(drum_hits(wav)),
        "bands": np.rint(analyze(wav) * 63).astype(np.uint8).tolist(),
        "events": events,
        "portraits": portraits,
        "flashes": flashes,
        "solos": solos,
        "special": special,
        "idle_portrait": idle_portrait,
    }
    with (MEDIA / "terminal-assets.json.gz").open("wb") as output:
        output.write(gzip.compress(json.dumps(data, separators=(",", ":")).encode("utf-8"), mtime=0))
    print(f"{duration:.3f}s, {len(data['bands'])} spectrum frames, {len(data['green'])} green accents")


if __name__ == "__main__":
    build(MEDIA / "Cybernetic-Full.wav")
