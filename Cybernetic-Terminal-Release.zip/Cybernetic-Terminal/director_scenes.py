"""Distinct glyph compositions for the two Cybernetic drops and recurring shots."""
from collections import Counter
import math

from cybernetic import hash16, ease
from player import DIM, NORMAL, BRIGHT, WHITE
from recut_scenes import SHOTS, FrameScene, centered_glyph, cipher, draw_scene, strbits
from visual_variation import BLUE, DEEP, VIOLET


RED = 13
FIRST_DROP = dict(zip(range(33,44),(
    "kelp", "jelly", "ink", "nautilus", "lens", "solo",
    "shoal", "plankton", "estuary", "pearl", "waterfall",
)))
SECOND_DROP = dict(zip(range(85,105),(
    "iris", "bolts", "fault_plane", "rail_bridge", "glyph_curtain",
    "shutters", "hinge", "torque", "cardiac", "solo",
    "wafer", "axon", "accelerator", "debris", "cavity",
    "comb", "checksum", "slats", "bitcrush", "vacuum",
)))
DROP_SCENES = FIRST_DROP | SECOND_DROP

# Revisited lyric ideas receive a new framing or a different object.
REPRISES = {
    17:"lyric_beam",19:"severed",26:"lyric_brackets",28:"rescue_light",
    44:"title_mosaic",45:"mirage",47:"oblique",48:"index_ledger",49:"suspended",
    51:"ticks",52:"hatch",54:"lyric_drop",56:"handoff",57:"mirror_code",
    59:"see_saw",61:"lyric_strobe",63:"ping_grid",64:"word_typeset",
    65:"cracks",66:"release",67:"afterimage",68:"stack_index",70:"cascade",
    71:"implosion",73:"waterline",74:"bit_scatter",75:"reconstruct",
    77:"large_title",78:"lyric_pair",79:"type_shear",80:"data_silt",
    83:"pinch",84:"black_gate",
}


def emit(c,x,y,i,seed,tone=NORMAL,radix="01"):
    c.put(x,y,radix[hash16(seed+i*297)%len(radix)],tone)


def curve_cloud(c,s,formula,count=310,radix="01",hue=NORMAL):
    for i in range(count):
        x,y,d=formula(i/count,i)
        tone=hue if d>.50 else VIOLET if d>.12 else BLUE if d>-.46 else DEEP
        emit(c,x,y,i,s.seed+int(s.t*11),tone,radix)


def bubbles(c,s,limit,radius,rate,twinned=False):
    ending=ease((limit-s.t)/.40)
    if ending<=.01:
        return
    step=math.floor(s.t*rate)
    for i in range(step-17,step+1):
        seed=hash16(i+round(rate*500))
        age=(s.t-i/rate)
        if age<0:
            continue
        r=radius*(.5+((seed>>3)%70)/93)
        x=5+(seed%96)+math.sin(age*1.6+seed)*2.7
        if twinned:
            x=8+(seed%91)+math.cos(age*2.1+i)*4.0
        y=28.4-age*(5.8+((seed>>4)%63)/10)
        if y<3.3-r or (ending<.57 and seed%9>=round(ending*14)):
            continue
        gleam=ease(age/.24)*ending
        if gleam<.07: continue
        if twinned:
            for k in range(12):
                a=k*math.tau/12+age*.6
                theta=math.floor(a/(math.pi/3))*(math.pi/3)+math.pi/6
                taper=math.cos(math.pi/6)/math.cos(a-theta)
                emit(c,x+r*math.cos(a)*taper,y+r*.68*math.sin(a)*taper,k,seed,
                     VIOLET if k%4==0 and gleam>.5 else BLUE,"02AF")
        else:
            for k in range(15):
                a=k*math.tau/15
                emit(c,x+r*math.cos(a),y+r*.65*math.sin(a),k,seed,
                     NORMAL if k in (9,10,11) and gleam>.45 else BLUE,"01")


def organic(c,s,kind):
    t=s.t
    def formula(u,i):
        if kind=="kelp":
            n=i%14; h=(i//14)/23
            root=7+7*n
            x=root+math.sin(t*1.5+h*5+n*.4)*(1+5*h)
            return x,28-h*(11+6*math.cos(n*.77+t*.3)),.66-h+.24*math.sin(n)
        if kind=="jelly":
            if i<128:
                a=math.pi+i/128*math.pi
                return 53+25*math.cos(a),14+6*math.sin(a),math.cos(a+t)
            line=i%12; v=(i-128)//12/15
            return 31+line*4+math.sin(t*2.7+v*7+line)*(1.7+v*5),14+v*13,.75-v*1.2
        if kind=="ink":
            spoke=i%8; v=(i//8)/38
            a=spoke*math.tau/8+v*v*2+.4*math.sin(t+spoke)
            return 50+45*v*math.cos(a),15+12*v*math.sin(a),.58-v+.3*math.sin(t+v*8)
        if kind=="nautilus":
            a=u*math.tau*4.2+t*.55
            r=3+38*u**1.6
            return 53+r*math.cos(a),17+r*.32*math.sin(a),math.sin(a+t)
        if kind=="lens":
            layer=i%6
            a=u*math.tau*6+t
            r=12+layer*5
            return 53+r*math.sin(a)*math.cos(layer*.28),15+(.40+.025*layer)*r*math.cos(a),.6-layer*.22
        if kind=="shoal":
            v=(i//13)/24; k=i%13
            return 7+v*94+1.7*math.sin(t+k*.8),6+k*1.42+math.sin(15*v-t*2+k*.23)*3.3,math.sin(v*20+t+k*.4)
        if kind=="plankton":
            n=hash16(s.seed+i*41)
            x=10+(n%84)+5*math.cos(t+.83*(n%9))
            y=6+((n//77)%21)+2.8*math.sin(t+(.53*(n%14)))
            return x,y,(.7*math.sin(t*1.9 + i*.82))
        if kind=="estuary":
            n=i%9; v=(i//9)/35
            x=54+90*(v-.5)
            return x,16+(n-4)*(1+.8*math.cos(v*math.tau+t*.41))+5*math.sin(v*7+t-.19*n),math.sin(2*t+.2*n+v*12)
        if kind=="pearl":
            k=i%16; v=(i//16)/20
            a=k*math.tau/16+t*.35
            r=17*math.sin(math.pi*v)
            return 54+r*math.cos(a)*1.65+6*math.sin(v*5+t),6+20*v+r*.33*math.sin(a),math.sin(a)
        k=i%20; v=(i//20)/16
        return 15+k*4.1+v*v*9*math.sin(k*.44),5+v*22+1.6*math.sin(k*.50+t*3),.77-.9*v
    curve_cloud(c,s,formula,323,"01:",NORMAL)


def control(c,s,kind):
    t,p=s.t,s.phase
    tick=int(t*15)
    # Each mechanical shot uses its own silhouette and movement axis.
    if kind=="iris":
        for k in range(9):
            radius=4+k*5
            x=54-radius
            y=16-round(radius*(.16+.13*ease(p)))
            c.box(x,y,2*radius,max(2,32-2*y),VIOLET if k%3==0 else BLUE)
            c.put(54+radius-5,y+1,strbits(tick+k*41,5,"01"),RED if p<.27 and k in (2,5) else NORMAL)
        return
    if kind in ("shutters","slats","comb"):
        for k in range(15):
            x=5+k*7
            y=5+round(11*math.sin(p*math.pi+k*.81)) if kind=="shutters" else 6+k%7
            reach=max(3,round((6+9*ease(p))*(.5+(k%5)*.12)))
            for q in range(reach):
                if kind=="slats": xx=x+k*.21+q*.50; yy=y+q
                elif kind=="comb": xx=x+math.sin(q*.4+t)*2; yy=26-q
                else: xx=x; yy=y+q
                emit(c,xx,yy,q,tick+k*41,BLUE if q%4 else VIOLET,"0123")
        return
    if kind in ("bitcrush","vacuum","cavity"):
        for row in range(5,28):
            reach=round((49-48*ease(p))*(1 if kind=="vacuum" else .42+.59*math.sin(row*.26+t)**2))
            if kind=="bitcrush":
                reach=round(46*abs(math.sin(t*.6+row*.24))*(.8+.2*s.bass))
            if kind=="cavity":
                reach=42
            for pos in range(-reach,reach+1,2):
                if kind=="cavity" and abs(pos)<10+ease(p)*17 and abs(row-16)<7:
                    continue
                yy=row+round(math.sin(pos*.17+t)*2)
                tint=VIOLET if abs(pos)%13<2 else BLUE if pos%5 else NORMAL
                emit(c,54+pos,yy,pos,tick+row*138,tint,"0128")
        return
    if kind=="checksum":
        for row in range(5,28,3):
            delta=round(17*math.sin(row*.8+p*5))
            c.put(11+delta,row,strbits(row*43+tick,32,"0123456789ABCDEF"),BLUE)
            c.put(62-delta,row,f"[0x{hash16(row+tick):04X}]",VIOLET)
            c.put(95,row,"OK" if row%4 else "00",NORMAL)
        return
    if kind=="glyph_curtain":
        for row in range(5,28):
            x=8+round(15*math.sin(row*.34-p*math.pi))
            c.put(x,row,strbits(row*111+tick,70,"0123456789ABCDEF"),DEEP if row%4 else BLUE)
        centered_glyph(c,"DROWN",10,3,tick)
        return
    def path(u,i):
        k=i%13;v=(i//13)/29
        a=u*math.tau
        if kind=="bolts":
            return 7+92*v,7+k*1.5+((int(v*16)+k)%5-2)*ease(p)*2.1,math.sin(t*3+u*11)
        if kind=="fault_plane":
            return 8+v*92+k*.45,5+k*1.65+5*math.sin(v*6+t)*ease(p),math.sin(v*17+t+k)
        if kind=="rail_bridge":
            z=.27+v*1.2
            return 54+(k-6)*6.4*z,7+20*v+2.3*math.sin(k*.55+t*4)*z,.7-z*.8
        if kind=="hinge":
            return 53+(v-.5)*90*math.cos(p*1.9+k*.045),(7+k*1.4)+(v-.5)*14*math.sin(p*2.72),math.sin(k+t)
        if kind=="torque":
            ang=math.tau*v+(k*.22)+p*1.1
            return 53+(14+k*2.3)*math.cos(ang),16+(6+k*.39)*math.sin(ang)+5*v*math.sin(t),math.cos(ang+t)
        if kind=="cardiac":
            x=7+93*v
            y=7+k*1.52
            pulse=5*math.exp(-((v-.5-.15*math.sin(3*t))/0.07)**2)
            return x,y-pulse*math.sin(5*v+k), .75-.11*k
        if kind=="wafer":
            return 20+5.2*k+v*18,7+14*v+3.7*math.sin(t+k*.47),math.sin(v*9+t)
        if kind=="axon":
            return 10+90*v,15+(k-6)*abs(math.sin(v*5+t))*.9+7*math.sin(v*math.tau+t),math.cos(v*11+k)
        if kind=="accelerator":
            a=k*math.tau/13+t*.7
            radius=7+49*v
            return 54+radius*math.cos(a),16+radius*.27*math.sin(a),.9-1.65*v
        n=hash16(s.seed+i*91)
        return 5+(n%100+int(p*32)*(i%4-1))%100,6+((n>>6)%21),.7*math.cos(n+t*2.1)
    curve_cloud(c,s,path,386,"012#A",RED if kind=="debris" and p<.22 else NORMAL)


def engraved_words(c,s,index,words,old,depart):
    line=(words or s.word).upper().strip()
    if not line:
        return
    data=(cipher(line)+" ")*6
    time=int(s.t*13)
    mode=index%5
    for row in range(5,29):
        length=92 if mode in (0,1) else round(88-2.1*abs(row-17))
        start=6+round(10*math.sin(row*.34+s.t)) if mode!=4 else 11+row%5
        at=(row*21+(time if row%2 else -time))%(len(data)//2)
        c.put(start,row,data[at:at+length],DEEP if row%4 else BLUE)
    for row in range(12,23):
        c.put(6,row," "*96,DEEP)
    keyword=s.word[:16] if s.word else line.split()[-1][:16]
    centered_glyph(c,keyword,13,2,s.seed+time)
    c.center(25,line[:100],RED if index==26 else WHITE)
    if old and (s.age<.23 or depart):
        c.put(7+time%16,8,old.upper()[:92],VIOLET)


def revisit(c,s,index,kind,words,old,depart):
    if kind in ("lyric_beam","lyric_brackets","lyric_drop","lyric_strobe","word_typeset","lyric_pair","type_shear"):
        engraved_words(c,s,index,words,old,depart)
        return
    if kind in ("large_title","title_mosaic"):
        for i in range(6):
            row=7+i*4
            c.put(7,row,strbits(s.seed+i*991+int(s.t*5),89,"0123456 ."),BLUE if i%2 else DEEP)
        centered_glyph(c,"CYBERNETIC",9 if kind=="large_title" else 14,3 if kind=="large_title" else 2,s.seed)
        return
    if kind=="black_gate":
        reach=round(1+20*ease((s.phase-.44)/.56))
        c.line(54-reach,16,54+reach,16,".",VIOLET)
        return
    stage=tuple(REPRISES).index(index)
    t=s.t
    def path(u,i):
        j=i%13; v=(i//13)/26
        a=v*math.tau
        form=stage%7
        p=s.phase
        if form==0:
            x=14+v*78
            y=6+j*1.5+(.3+stage*.1)*math.sin(v*(12+stage*.12)+t+j*p)
        elif form==1:
            x=55+(8+j*3)*math.cos(a+.3*t)+math.sin(j*.11*t)*stage*.32
            y=16+(2+j*.57)*math.sin(a*(1+stage*.06)+t*.7)
        elif form==2:
            x=8+j*7.2+math.sin(v*12+t+j)*p*7
            y=6+21*v+.9*math.cos(j+t)
        elif form==3:
            x=7+v*94+math.sin(t*.71+j)*4
            y=16+(j-6)*(1.1+.91*math.cos(v*8+t))
        elif form==4:
            x=54+(v-.5)*96*math.cos(j*.067+t*.17)
            y=5+j*1.5+(v-.5)*9*math.sin(t+j*.13)
        elif form==5:
            x=54+(8+j*3.6)*math.cos(a+(j*.25)*p*stage*.18)
            y=16+(2+j*.63)*math.sin(a+(j*.34)*p)
        else:
            x=12+v*87+math.cos(t+p*j)*j*.46
            y=6+j*1.56+((i%9)-4)*p*1.4
        return x,y,math.sin(t+u*(5+stage*.18))*.85
    curve_cloud(c,s,path,351,"01:." if stage%3 else "012F",NORMAL)
    if kind in ("implosion","pinch","data_silt"):
        feed=round(37*(1-ease(s.phase)))
        c.line(54-feed,16,54+feed,16,"=",VIOLET)
    if s.word and kind not in ("pinch","hatch"):
        c.put(7+(stage*17)%56,5+(stage%4),s.word,VIOLET if stage%3==0 else BLUE)


def compose(c,s,index,words,old,depart):
    if index in FIRST_DROP:
        organic(c,s,FIRST_DROP[index])
    elif index in SECOND_DROP:
        control(c,s,SECOND_DROP[index])
    elif index in REPRISES:
        revisit(c,s,index,REPRISES[index],words,old,depart)
    else:
        draw_scene(c,s,SHOTS[index].scene,words,old,depart)
