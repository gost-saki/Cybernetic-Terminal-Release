"""Bake opening cuts from harmonic and percussive changes in the source WAV."""
import wave

import numpy as np

from terminal_opening import CUES, OPEN_END


def opening_cuts(path):
    with wave.open(str(path), "rb") as source:
        rate = source.getframerate()
        count = min(source.getnframes(), round((OPEN_END + 1) * rate))
        stereo = np.frombuffer(source.readframes(count), dtype="<i2")
        stereo = stereo.reshape(-1, source.getnchannels()).astype(np.float32) / 32768

    hop = round(rate * .005)
    window = 2048
    weights = np.hanning(window)
    mid = stereo.mean(axis=1)
    side = (stereo[:, 0] - stereo[:, 1]) * .5 if stereo.shape[1] == 2 else np.zeros_like(mid)
    mids = np.lib.stride_tricks.sliding_window_view(np.pad(mid, window // 2), window)[::hop]
    sides = np.lib.stride_tricks.sliding_window_view(np.pad(side, window // 2), window)[::hop]
    frequencies = np.fft.rfftfreq(window, 1 / rate)
    medium = (frequencies >= 270) & (frequencies < 3900)
    low = (frequencies >= 42) & (frequencies <= 205)
    voice_parts, beat_parts = [], []
    for i in range(0, len(mids), 480):
        center = np.abs(np.fft.rfft(mids[i:i + 480] * weights, axis=1)) / weights.sum()
        lateral = np.abs(np.fft.rfft(sides[i:i + 480] * weights, axis=1)) / weights.sum()
        voice_parts.append(np.maximum(center[:, medium] - .66 * lateral[:, medium], 0))
        beat_parts.append(center[:, low])
    melody = np.concatenate(voice_parts, axis=0)
    bass = np.concatenate(beat_parts, axis=0)

    # Favor sustained narrowband energy near the stereo center for vocal accents.
    # Compute the drum track independently from the bass attack.
    neighbors = np.pad(melody, ((0, 0), (2, 2)), mode="edge")
    floor = (neighbors[:, :-4] + neighbors[:, 4:]) * .5
    tonal = np.log1p(1200 * np.maximum(melody - .65 * floor, 0))
    low_energy = np.log1p(680 * bass)
    voice_attack = np.maximum(tonal[4:] - tonal[:-4], 0).mean(axis=1)
    drum_attack = np.maximum(low_energy[3:] - low_energy[:-3], 0).mean(axis=1)
    voice_attack = np.pad(voice_attack, (2, 2))
    drum_attack = np.pad(drum_attack, (1, 2))
    voice_attack = np.convolve(voice_attack, [.18, .64, .18], mode="same")
    drum_attack = np.convolve(drum_attack, [.2, .6, .2], mode="same")

    cuts = []
    for center, _, _, driver in CUES:
        if driver == "fixed":
            cuts.append(center)
            continue
        radius = .42 if driver == "voice" else .36
        low_index = max(2, round((center - radius) * rate / hop))
        high_index = min(len(voice_attack) - 2, round((center + radius) * rate / hop))
        if low_index >= high_index:
            cuts.append(center)
            continue
        indices = np.arange(low_index, high_index)
        distance = abs(indices * hop / rate - center) / radius
        voice = voice_attack[indices]
        drum = drum_attack[indices]
        voice = voice / max(.02, np.quantile(voice, .92))
        drum = drum / max(.02, np.quantile(drum, .92))
        score = (.84 * voice + .16 * drum) if driver == "voice" else (.84 * drum + .16 * voice)
        best = indices[np.argmax(score * (1 - .38 * distance))]
        cuts.append(round(float(best * hop / rate), 3))
    return cuts
