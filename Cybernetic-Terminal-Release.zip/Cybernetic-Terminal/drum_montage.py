"""Render the rising percussion montage as full-width terminal characters."""
from base64 import b64decode
from bisect import bisect_right
import gzip
import json

from visual_variation import frame_clock


# Stamp the broad hits first, then the eighth notes and final pickup.
BEATS = (
    52.325, 52.805, 53.260, 53.715, 54.170, 54.625, 55.080, 55.530,
    55.985, 56.445, 56.670, 56.895, 57.125, 57.350, 57.580, 57.805,
    58.035, 58.260, 58.490, 58.620,
)
START = BEATS[0]
STYLE_BASE = 64
SHADES = 16
TONES = (
    (219, 232, 255), (72, 212, 244), (251, 116, 195), (177, 133, 255),
    (250, 159, 77), (241, 70, 106), (239, 214, 111), (72, 212, 177),
)
COLORS = {
    STYLE_BASE + family * SHADES + shade: tuple(
        round(channel * (.045 + .955 * (shade / (SHADES - 1)) ** 1.1)) for channel in color
    )
    for family, color in enumerate(TONES)
    for shade in range(SHADES)
}
CODESETS = ("10XAF3C8", "b7e29f3a", "8fA41D9E", "5X0C3E71")
TEXTURES = tuple(
    tuple(
        (
            "·" if (code & 15) <= 2 else signs[i % 8],
            STYLE_BASE + (code & 127),
        )
        for code in range(256)
        for i in range(8)
    )
    for signs in CODESETS
)


class DrumMontage:
    def __init__(self, path):
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            atlas = json.load(stream)
        self.width, self.height = atlas["grid"]
        self.frames = tuple(b64decode(frame) for frame in atlas["frames"])
        if len(self.frames) != len(BEATS) or any(
            len(frame) != self.width * self.height for frame in self.frames
        ):
            raise ValueError("Drum montage atlas does not match its timeline")

    def draw(self, canvas, time):
        shot = bisect_right(BEATS, time) - 1
        age = time - BEATS[shot]
        frame = self.frames[shot]
        width, height = canvas.w, canvas.h - 6
        target = self.width
        columns = [(2 * x + 1) * target // (2 * width) for x in range(width)]
        look = TEXTURES[shot % len(TEXTURES)]
        tick = int(age * 20 + .04)
        # Only the peripheral rows jump on attack. Keep the focal features readable.
        ribbon = shot >= 9 and age < .075
        for y in range(height):
            sy = (2 * y + 1) * self.height // (2 * height)
            start = sy * target
            side = (y + shot * 5) % 9 < 2
            direction = (-1 if shot % 2 else 1) if ribbon and side else 0
            shift = direction * max(1, target // 31)
            row = []
            for x, col in enumerate(columns):
                byte = frame[start + (col + shift) % target]
                grain = (x * 5 + y * 3 + (x // 7 ^ y // 4) + tick) & 7
                if byte & 128 and (x + y) % 5 == 0:
                    # One thin contour glyph sits above the code texture.
                    mark, style = look[(byte & 127) * 8 + grain]
                    row.append((":" if grain < 4 else "/", style))
                else:
                    row.append(look[byte * 8 + grain])
            canvas.cells[y + 2] = row
        canvas.put(2, 1, "CYBERNETIC", STYLE_BASE + 31)
        clock = frame_clock(time)
        canvas.put(width - len(clock) - 2, 1, clock, STYLE_BASE + 25)
