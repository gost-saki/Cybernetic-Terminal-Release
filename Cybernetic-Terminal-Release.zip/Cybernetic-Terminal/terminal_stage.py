"""Shared native character scene composition for both playback and export."""
from bisect import bisect_right
import math

from cybernetic import beat_transition, ease, hash16, shift_strip, tear_strips
from director_scenes import FIRST_DROP, RED, SECOND_DROP, bubbles, compose
from player import BRIGHT, Canvas
from recut_scenes import FrameScene, SHOTS
from terminal_timing import GRID, OUTRO
from visual_variation import BLUE, DEEP, FPS, VIOLET, frame_clock


STAGE_TOP,STAGE_BOTTOM=4,28
LYRIC_WALLS={"lyric","typewall","field"}


# Each solo uses an upper-body illustration and a different measured mouth centre.
SOLOS = {38:(0,(659,674),.01),94:(4,(658,648),.055)}
VOCALS = {38:(.0,.19,.39,.60),94:(.0,.31,.62,.94,1.23)}
RIBBONS = (
    (6.52,1.18,1,0), (17.26,1.20,-1,0), (26.60,1.26,0,-1),
    (39.71,1.28,1,1), (47.33,1.25,-1,-1), (69.63,1.15,0,1),
    (80.52,1.20,1,-1), (101.34,1.07,-1,0), (119.21,1.12,0,-1),
    (130.12,1.25,-1,1), (145.63,1.12,1,0), (157.01,1.14,0,-1),
    (169.24,.98,-1,-1), (175.60,1.12,1,-1),
)
RED_STRIKES = (47.32,151.22,169.17)


def cue_at(lyrics, lyric_times, time):
    index=bisect_right(lyric_times,time)-1
    if index<0:
        return "",None,None,None
    at,words=lyrics[index]
    next_time=lyric_times[index+1] if index+1<len(lyric_times) else OUTRO
    # The two isolated hook lines lead into long instrumental passages.
    if next_time-at>9 and time-at>5.6:
        words=""
    before=lyrics[index-1][1] if index else None
    return words,before,at,next_time

def spectrum_strip(c,time,bass,columns):
    w,h=GRID
    c.put(2,h-8,"-"*(w-4),DEEP)
    for x in range(3,w-3):
        amp=(columns[round((len(columns)-1)*(x-3)/(w-7))]
             if columns is not None else min(1,bass*.35+.23*abs(math.sin(x*.13+time))))
        if amp>.09:
            c.put(x,h-9,"1" if amp>.47 else ".",VIOLET if amp>.72 else BLUE)

def drift(c,time):
    for i,(start,duration,dx,dy) in enumerate(RIBBONS):
        age=(time-start)/duration
        if not 0<age<1:
            continue
        fade=min(ease(age/.25),ease((1-age)/.20))
        count=round(15+fade*32)
        for k in range(count):
            n=hash16(19*i+k*131)
            lag=(n%17)/45
            x=(4+age*100*dx+105*(dx<0)+lag*37*(-dx)) if dx else 8+k*2.0
            y=(6+age*21*dy+21*(dy<0)-lag*17*dy) if dy else 7+(n//41)%20
            x+=k%12-6
            y+=(k%5-2)*.51
            tint=RED if i in (5,12) and .36<age<.55 and k%9==0 else VIOLET if k%8==0 else BLUE if fade>.4 else DEEP
            c.put(x,y,"0123456789ABCDEF"[n&15],tint)


def compose_stage(time, bass, columns, index, start, end, cue, trigger_times, overlay):
    age=time-start
    words,previous,at,next_time=cue
    shot=SHOTS[index]
    phase=age/(end-start)
    enter=at is not None and 0<=time-at<.21 and (words or previous)
    leave=words and next_time is not None and 0<=next_time-time<.18
    wall=shot.scene in LYRIC_WALLS or index in (17,26,54,61,64,78,79,89)
    wall_exit=wall and end-time<.17
    first=index in FIRST_DROP
    second=index in SECOND_DROP
    seed=hash16(9131+index*157)
    scene=FrameScene(time,age,phase,bass,seed,shot.word)
    c=Canvas(*GRID)
    w,h=GRID
    c.put(2,1,"CYBERNETIC",BRIGHT)
    c.put(w-15,1,frame_clock(time),BLUE)
    c.clip=(STAGE_TOP,STAGE_BOTTOM)
    ghost=previous if enter or (wall and age<.13) else words if leave or wall_exit else None
    compose(c,scene,index,words,ghost,leave or wall_exit)
    quiet=index==84 or shot.scene=="gate"
    if enter and previous and not wall and not quiet:
        c.put(6+hash16(seed+int(time*24))%19,7,"// "+previous.upper()[:79],VIOLET)
    if first:
        bubbles(c,scene,71.77,3.3,6.4)
    elif second:
        bubbles(c,scene,OUTRO,2.8,5.1,twinned=True)
    if not quiet:
        drift(c,time)
    overlay(c,scene,index,columns)

    past=bisect_right(trigger_times,time)-1
    attack=time-trigger_times[past] if past>=0 else 9
    impact=(.91 if first or second else .55)*max(0,1-attack/.15)
    if enter or leave or wall_exit:
        impact=max(impact,.67 if enter else .59)
    if age<.12:
        impact=max(impact,(.80 if first or second else .51)*(1-age/.16))
    strips=[]
    if impact>.25 and not quiet:
        strips=list(tear_strips(w,STAGE_TOP,STAGE_BOTTOM,.025+(1-impact)*.13,impact,
                                hash16(seed+int(time*FPS/2))))
        if impact>.68:
            if second:
                beat_transition(c,STAGE_TOP,STAGE_BOTTOM,.12+.1*phase,impact,
                                "split" if index%2 else "sweep")
            elif first:
                y=8+(index*7)%17
                c.put(5,y,".0"*46,BLUE)
        for q in strips:
            shift_strip(c,q.row,q.left,q.right,q.offset)
            c.put(q.digit_start,q.row,q.digits,q.style)
        if (enter and time-at<2/FPS or leave and next_time-time<2/FPS or wall_exit and end-time<2/FPS):
            c.put(5,6+hash16(seed+int(time*FPS))%20,"1.="*31,VIOLET)
    if any(0<=time-mark<.125 for mark in RED_STRIKES):
        c.put(7,24,"F0:0F  0xFF  "+("01_"*15),RED)
    c.clip=None
    if not quiet:
        spectrum_strip(c,time,bass,columns)
    return c, strips
