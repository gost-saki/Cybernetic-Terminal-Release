"""Breathing foreground portrait and the HELP ME warning field behind it."""
from math import cos, tau

from cybernetic import ease, hash16
from terminal_art import CODE, ICE, LILAC
from terminal_errors import paint_stamps
from terminal_timing import IDLE_START, OUTRO
from visual_variation import DEEP


def breathing(time, height):
    phase = (time - IDLE_START) / 2.45
    rise = (1 - cos(phase * tau)) / 2
    travel = max(1.0, height * .068)
    return travel * (1 - rise), height - travel - 1 + travel * .54 * rise


def paint_idle(canvas, grid, time, box, widest_left):
    left, top, right, bottom = box
    height = bottom - top + 1
    release = ease((time - (OUTRO - .34)) / .34)
    backing = (widest_left, top, canvas.w - widest_left - 1, bottom)
    paint_stamps(canvas, "HELP ME", backing, (time - IDLE_START) / 2.7, release,
                 clip=(left, right))

    width = min(right - left + 1, round(height * 1.93), round(canvas.w * .46))
    x0 = (canvas.w - width) // 2
    drift, size = breathing(time, height)
    rows, cols = len(grid), len(grid[0])
    samples = [(2 * x + 1) * cols // (2 * width) for x in range(width)]
    for y in range(top, bottom + 1):
        source_y = (y - top + .5 - drift) / size
        if not 0 <= source_y < 1:
            continue
        iy = int(source_y * rows)
        row = grid[iy]
        for x, ix in enumerate(samples, x0):
            value = ord(row[ix]) - 65
            if value == 0:
                continue
            power = value & 7
            if power:
                tone = (LILAC if value & 8 else ICE) + power
                code = CODE[hash16(ix * 173 + iy * 207) & 15]
                canvas.put(x, y, code, tone)
            else:
                # Dark body pixels are opaque, including the eyes and smile.
                canvas.put(x, y, " ", DEEP)
