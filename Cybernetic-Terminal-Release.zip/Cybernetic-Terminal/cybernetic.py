"""Palette and shared geometry for the Cybernetic terminal scenes."""
import math
import random
from typing import NamedTuple

from player import BRIGHT, DIM, NORMAL, WHITE

VIOLET, BLUE, DEEP = 4, 5, 6
PALETTE = {
    DIM: (62, 120, 156),
    NORMAL: (78, 186, 224),
    BRIGHT: (106, 241, 255),
    WHITE: (230, 249, 255),
    VIOLET: (161, 130, 245),
    BLUE: (50, 101, 174),
    DEEP: (27, 56, 103),
}
FPS = 24


def clamp(x,a=0,b=1):return min(b,max(a,x))


def hash16(i):
    v=(i+0x9E3779B9)&0xFFFFFFFF
    v=((v^(v>>16))*0x7FEB352D)&0xFFFFFFFF
    v=((v^(v>>15))*0x846CA68B)&0xFFFFFFFF
    return (v^(v>>16))&65535


def ease(fraction):
    fraction = clamp(fraction)
    return fraction * fraction * (3 - 2 * fraction)


def shift_strip(canvas, row, left, right, shift):
    """Displace one slice without wrapping characters across its edges."""
    region = canvas.cells[row][left:right]
    blanks = [(" ", DEEP)] * abs(shift)
    if shift > 0:
        shifted = (blanks + region)[:len(region)]
    else:
        shifted = (region + blanks)[-len(region):]
    canvas.cells[row][left:right] = shifted


def beat_transition(canvas, top, bottom, time, strength, kind):
    width = canvas.w
    center = (top + bottom) / 2
    progress = clamp(time / 0.32)
    if kind == "split":
        spread = round(math.sin(progress * math.pi) * (4 + 11 * strength))
        if spread == 0:
            return
        for row in range(top, bottom + 1):
            direction = -1 if row < center else 1
            shift_strip(canvas, row, 2, width - 2, direction * spread)
        edge = 2 + spread
        canvas.line(edge, center - 1, width - edge - 1, center - 1, "-", VIOLET)
        canvas.line(2, center + 1, width - 3, center + 1, ".", NORMAL)
        return

    head = -12 + progress * (width + 24)
    band = round(7 + 12 * strength)
    for row in range(top, bottom + 1):
        edge = round(head + (row - center) * 1.15)
        left = max(2, edge - band)
        right = min(width - 2, edge)
        if right > left:
            canvas.put(left, row, " " * (right - left), DEEP)
        if 2 <= edge < width - 2:
            canvas.put(edge, row, "/" if row % 3 else "+", VIOLET if row % 4 else NORMAL)


class TearStrip(NamedTuple):
    row: int
    left: int
    right: int
    offset: int
    digit_start: int
    digits: str
    style: int


def tear_strips(width, top, bottom, time, strength, seed):
    duration = 0.14 + strength * 0.105
    decay = 1 - time / duration
    if decay <= 0:
        return
    # Repeat the same realization on seek. Refresh the strips every two frames.
    noise = random.Random(seed + int(time * FPS / 2))
    strips = 2 + round(6 * strength * decay)
    for row in noise.sample(range(top, bottom + 1), min(strips, bottom - top + 1)):
        left = noise.randint(2, width // 3)
        right = noise.randint(2 * width // 3, width - 2)
        offset = noise.choice((-1, 1)) * noise.randint(2, 4 + round(17 * strength * decay))
        count = noise.randint(4, min(right - left, 7 + round(18 * strength * decay)))
        start = noise.randint(left, right - count)
        digits = "".join(noise.choices("0011:|+-  ", k=count))
        yield TearStrip(row, left, right, offset, start, digits, noise.choice((VIOLET, NORMAL, BLUE)))
