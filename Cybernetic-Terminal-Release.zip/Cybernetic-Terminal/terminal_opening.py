"""The opening montage combines circuit shapes with cuts baked from the WAV."""
from bisect import bisect_right
from math import cos, sin, tau

from climax_layers import opening
from cybernetic import ease, hash16
from opening_geometry import COMPOSITIONS
from player import BRIGHT, NORMAL, WHITE, Canvas
from terminal_art import CODE, RED_EDGE
from terminal_details import paint_board_details
from terminal_finale import COMPACT, WIDE, block_points, block_width
from terminal_instruments import orbital_trace, routing_rack, sonar, aperture
from terminal_timing import GRID
from visual_variation import BLUE, DEEP, VIOLET, frame_clock


OPEN_END = 58.71

# Each position is a search center, in seconds. The WAV sets the actual cut.
# Labels are art direction for the phrase, independent of the subtitle timeline.
CUES = (
    (0.0, "power", "", "fixed"),
    (1.56, "pins", "", "beat"),
    (3.68, "orbit", "", "voice"),
    (5.59, "hold", "", "voice"),
    (7.95, "barrier", "", "voice"),
    (9.82, "fork", "", "beat"),
    (11.34, "through", "GO THROUGH", "voice"),
    (12.77, "wave", "", "voice"),
    (14.26, "scope", "", "beat"),
    (15.38, "route", "", "voice"),
    (16.47, "bus", "", "beat"),
    (17.18, "title", "", "fixed"),
    (23.02, "skew", "", "fixed"),
    (24.68, "scan", "", "voice"),
    (26.62, "beacon", "", "voice"),
    (28.25, "relay", "", "beat"),
    (29.94, "packet", "", "voice"),
    (31.53, "hurt", "MAKE IT HURT", "voice"),
    (33.49, "tether", "", "voice"),
    (35.15, "release", "", "beat"),
    (36.91, "memory", "", "voice"),
    (38.62, "bank", "", "beat"),
    (40.14, "readout", "", "voice"),
    (41.67, "undertow", "", "voice"),
    (43.18, "current", "", "beat"),
    (44.37, "flood", "", "voice"),
    (45.61, "fault", "", "beat"),
    (47.17, "bits", "INTO BITS", "voice"),
    (48.68, "rescue", "", "voice"),
    (50.24, "recovery", "", "beat"),
    (51.68, "identity", "CYBERNETIC", "voice"),
    (53.45, "echo", "", "voice"),
    (55.39, "sink", "", "voice"),
    (56.83, "gate", "", "beat"),
    (58.22, "quiet", "", "fixed"),
)


class Board:
    def __init__(self, canvas):
        self.c = canvas
        self.left = max(3, canvas.w // 18)
        self.top = 4
        self.width = canvas.w - 1 - self.left * 2
        self.height = max(1, canvas.h - 9 - self.top)
        self.area = (self.left, self.top, self.left + self.width, self.top + self.height)

    def xy(self, x, y):
        return self.left + round(self.width * x), self.top + round(self.height * y)

    def point(self, x, y, mark, ink=NORMAL):
        self.c.put(*self.xy(x, y), mark, ink)

    def line(self, x0, y0, x1, y1, mark, ink=NORMAL):
        self.c.line(*self.xy(x0, y0), *self.xy(x1, y1), mark, ink)

    def box(self, x, y, width, height, ink=BLUE):
        left, top = self.xy(x, y)
        right, bottom = self.xy(x + width, y + height)
        self.c.box(left, top, right - left + 1, bottom - top + 1, ink)

    def plane(self, x, y, width, height, ink=DEEP):
        left, top = self.xy(x, y)
        right, bottom = self.xy(x + width, y + height)
        for row in range(top, bottom + 1):
            mark = "/" if row % 2 else "·"
            self.c.put(left, row, mark * (right - left + 1), ink)

    def label(self, x, y, text, ink=BRIGHT):
        a, b = self.xy(x, y)
        self.c.put(a - len(text) // 2, b, text, ink)


def pads(board, tick, stride, ink=DEEP):
    for row in range(1, 10):
        for x in range(2, 20, stride):
            val = hash16(row * 1381 + x * 191)
            glyph = "+" if val % 11 < 2 else "." if val % 3 else "·"
            if val % 13 == tick % 13:
                glyph = "o"
            board.point(x / 20, row / 10, glyph, NORMAL if glyph in "+o" else ink)


def traces(board, phase, bass):
    for i in range(3):
        y = (i + 1) / 4
        board.line(.055, y, .94, y, "─", VIOLET if i % 2 else NORMAL)
        board.point(.055, y, "o", NORMAL)
        board.point(.94, y, "+", NORMAL)
        travel = (phase + i * .17) % 1
        board.point(.055 + travel * .885, y, ">", WHITE if bass > .54 else BRIGHT)


def wave(board, time, bass, splashes=False):
    for channel in (0, 1):
        for ix in range(117):
            u = ix / 116
            v = .45 + .23 * sin(u * tau * 1.4 - time * 7 + channel * .92)
            v += (.055 + .09 * bass) * cos(u * tau * 3.2 + time * 4)
            char = "≈" if ix % 11 == 0 else "·"
            board.point(u, v + channel * .12, char, VIOLET if channel else NORMAL)
            if splashes and ix % 9 == 0:
                board.point(u, max(.02, v - .14), "o", BLUE)


def fragments(board, time, *, falling=False, amount=80):
    tick = int(time * 14)
    for i in range(amount):
        key = hash16(i * 443 + 8311)
        x = (key % 251) / 250
        y = ((key // 251) % 137) / 136
        if falling:
            y = (y + time * (.18 + (key % 8) * .053)) % 1
        elif i % 3 == 0:
            x = (x + time * .16) % 1
        mark = CODE[(key + tick) & 15] if i % 9 == 0 else "·+.:/"[key % 5]
        board.point(x, y, mark, VIOLET if i % 5 == 0 else BLUE)


def chip(board, phase, bass):
    board.plane(.31, .24, .38, .29)
    board.box(.31, .24, .38, .29, NORMAL)
    for i in range(5):
        x = .34 + i * .08
        board.line(x, .13, x, .24, ":", BLUE)
        board.line(x, .53, x, .67, ":", BLUE)
        board.point(x, .13, "+", BRIGHT if i == int(phase * 5) else NORMAL)
    board.label(.5, .39, f"0x{round(255 * bass):02X}", WHITE)


def large_lyric(board, text, bass, tick):
    room = board.width - 4
    font = WIDE if block_width(text, WIDE) <= room else COMPACT
    if block_width(text, font) > room:
        text = text.split()[-1]
    width = block_width(text, font)
    left = (board.c.w - width) // 2
    top = board.top + max(0, (board.height - 5) // 2)
    for y in range(top, top + 5):
        board.c.put(left - 1, y, " " * (width + 2), DEEP)
    for x, y in block_points(text, font):
        ink = RED_EDGE if text in ("MAKE IT HURT", "INTO BITS") else WHITE if bass > .4 else BRIGHT
        board.c.put(left + x, top + y, CODE[(x * 3 + y + tick) & 15], ink)


def draw_title(canvas, time):
    frame = Canvas(*GRID)
    opening(frame, time)
    top, bottom = 4, canvas.h - 6
    for y in range(top, bottom):
        row = frame.cells[(y - top) * (GRID[1] - 7) // max(1, bottom - top) + 3]
        canvas.cells[y] = [row[x * GRID[0] // canvas.w] for x in range(canvas.w)]


def paint_opening(canvas, time, cue_times, bass, bands):
    index = max(0, bisect_right(cue_times, time) - 1)
    _, mode, text, _ = CUES[index]
    start = cue_times[index]
    age = time - start
    end = cue_times[index + 1] if index + 1 < len(cue_times) else OPEN_END
    phase = (age * (1.15 + bass * .4)) % 1
    canvas.put(2, 1, "CYBERNETIC", BRIGHT)
    clock = frame_clock(time)
    canvas.put(canvas.w - len(clock) - 2, 1, clock, BLUE)
    board = Board(canvas)
    tick = int(time * 9)

    if mode == "quiet":
        return
    if mode == "title":
        draw_title(canvas, time)
        paint_board_details(canvas, board.area, mode, index, age, time, bass, bands)
        return
    if mode in COMPOSITIONS:
        COMPOSITIONS[mode](board, time, bass, bands)
    elif mode == "power":
        pads(board, tick, 3)
        chip(board, phase, bass)
    elif mode == "orbit":
        orbital_trace(canvas, board.area, time, bass)
        pads(board, tick, 4)
    elif mode == "hold":
        traces(board, phase, bass)
        board.box(.39, .28, .22, .42, VIOLET)
    elif mode == "route":
        routing_rack(canvas, board.area, time, bass)
    elif mode in ("wave", "undertow", "flood", "sink", "current"):
        if mode in ("flood", "sink"):
            zone = .34 + .42 * ease(age / max(.1, end - start))
            board.plane(.03, 1 - zone, .94, zone, BLUE)
        if mode in ("undertow", "current", "sink"):
            fragments(board, time, falling=True, amount=83)
        wave(board, time, bass, splashes=mode in ("undertow", "flood"))
    elif mode == "scan":
        sonar(canvas, board.area, time, bass)
    elif mode == "gate":
        aperture(canvas, board.area, time, bass)
    else:
        fragments(board, time, falling=mode == "fault", amount=122 if mode == "fault" else 77)
        if mode == "fault":
            board.line(.05, .23, .91, .74, "/", VIOLET)
    if mode not in COMPOSITIONS:
        paint_board_details(canvas, board.area, mode, index, age, time, bass, bands)
    if text:
        large_lyric(board, text, bass, tick)
    if index and age < .105 and bass > .30:
        row = board.top + index % board.height
        left = board.left + (index * 13) % max(1,board.width - 10)
        canvas.put(left, row, "0x" + CODE[index % len(CODE)] + "/::", VIOLET)

    # One low bar remains tethered to the recording instead of scrolling lyrics.
    if canvas.h >= 25 and mode in ("wave", "undertow", "flood", "sink", "current"):
        length = max(9, board.width // 3)
        left = (canvas.w - length) // 2
        line = "".join("─" if bands[(i * 2) % len(bands)] < .5 else "═" for i in range(length))
        canvas.put(left, canvas.h - 7, line, BLUE)
