"""Play the complete Cybernetic character MV on a native Windows console."""
from bisect import bisect_right
import gzip
import json
from pathlib import Path
import sys

from climax_layers import BUILD_BEATS, BURST, CLEAR, DROP_START, FIRST_DRIVER, SECOND_DRIVER, ClimaxLayers, hit
from cybernetic import PALETTE, ease, hash16
from drum_montage import COLORS as DRUM_COLORS
from drum_montage import START as DRUM_START, DrumMontage
from player import BRIGHT, DIM, NORMAL, WHITE, Canvas, wrap, width as text_width
from pressure_stage import BLACK as SCAN_BLACK
from pressure_stage import END, REENTRY, RETURN, SCAN_OFF, SLICE_START, START, circuit_overload, pressure_canvas, restart_canvas
from recut_scenes import SHOTS
from terminal_art import (
    CODE, CYAN_EDGE, GLITCH_END, GLITCH_START, GREEN, ICE, LILAC, PURPLE_EDGE, RED_EDGE,
    jaw_at, paint_art, paint_character, title_cover,
)
from terminal_details import paint_ecg_details, paint_later_details
from terminal_errors import ERROR_DIM, ERROR_DUST, ERROR_RED, paint_errors, release_at
from terminal_finale import LYRIC_RED, LYRIC_SHADOW, PANEL_DARK, PANEL_EDGE, PANEL_MID, paint_finale
from terminal_idle import paint_idle
from terminal_instruments import LOG_START, paint_instruments
from terminal_opening import CUES, OPEN_END, paint_opening
from terminal_stage import SOLOS, VOCALS, compose_stage, cue_at
from terminal_tearing import TEAR_COLORS, TEAR_PEAK, TEAR_RELEASE, paint_signal_tear
from terminal_timing import (
    BLACK, CHORUSES, GRID, LYRIC_DELAY, OUTRO, OUTRO_COLORS, PIANO_KEYS, POWER_OFF, ZERO, pulse_canvas,
)
from visual_variation import BLUE, DEEP, FPS, VIOLET, lyric_entries


ROOT = Path(__file__).resolve().parent
MEDIA = ROOT / "media"
CONTROLS = "SPACE play/pause   <- -> 5s   R restart   Q quit   H help"
CONTROL_INK = 36

COLORS = {**PALETTE, **OUTRO_COLORS, **TEAR_COLORS, **DRUM_COLORS, 13: (253, 61, 86),
          GREEN: (59, 209, 103), CYAN_EDGE: (59, 185, 231),
          PURPLE_EDGE: (167, 75, 219), RED_EDGE: (238, 48, 108),
          CONTROL_INK: (255, 255, 255),
          PANEL_DARK: (34, 47, 85), PANEL_MID: (75, 105, 170),
          PANEL_EDGE: (123, 174, 232), LYRIC_RED: (255, 63, 83),
          LYRIC_SHADOW: (118, 22, 43),
          ERROR_RED: (255, 55, 75), ERROR_DIM: (186, 31, 60), ERROR_DUST: (142, 29, 64)}
for base, bright in ((ICE, (211, 236, 255)), (LILAC, (184, 134, 248))):
    for step in range(1, 8):
        COLORS[base + step] = tuple(round(value * (step / 7) ** 1.12) for value in bright)
STYLES = {style: "\x1b[38;2;{};{};{}m".format(*rgb) for style, rgb in COLORS.items()}


class TerminalCanvas(Canvas):
    def ansi(self, *, left=0, top=0):
        commands = ["\x1b[H\x1b[48;2;0;0;0m"]
        last = None
        for y, row in enumerate(self.cells):
            commands.append(f"\x1b[{top + y + 1};{left + 1}H")
            for char, style in row:
                if not char:
                    continue
                if char != " " and last != style:
                    commands.append(STYLES[style])
                    last = style
                commands.append(char)
        commands.append("\x1b[0m")
        return "".join(commands)


def fit(canvas, source):
    rows = canvas.h - 1
    columns = canvas.w
    x_samples = [col * source.w // columns for col in range(columns)]
    for y in range(rows):
        source_row = source.cells[y * source.h // rows]
        canvas.cells[y] = [source_row[x] for x in x_samples]


class TerminalFilm:
    title = "Cybernetic"
    background = (0, 0, 0)
    chapters = [(0,), (58.71,), (77.0,), (151.555,), (179.75,)]

    def __init__(self):
        with gzip.open(MEDIA / "terminal-assets.json.gz", "rt", encoding="utf-8") as stream:
            self.assets = json.load(stream)
        self.drum_montage = DrumMontage(MEDIA / "drum-montage.json.gz")
        self.config = {"audio": str(MEDIA / "Cybernetic-Full.wav"),
                       "duration": self.assets["duration"], "subtitle_offset": 0.0}
        self.translations = json.loads((MEDIA / "Cybernetic.zh.json").read_text(encoding="utf-8"))
        self.lyrics = [(round(at + LYRIC_DELAY, 3), words)
                       for at, words in lyric_entries(MEDIA / "Cybernetic.lrc")]
        self.lyric_times = [at for at, _ in self.lyrics]
        self.times = [at for at, words in self.lyrics if words]
        self.cuts = self.assets["shot_times"]
        self.opening_cues = self.assets.get("opening_cues", [cue[0] for cue in CUES])
        self.triggers = self.assets["trigger_times"]
        self.green = self.assets["green"]
        self.bands = self.assets["bands"]
        self.events = self.assets["events"]
        self.event_times = [time for time, *_ in self.events]
        self.layers = ClimaxLayers()
        self.cover_cache = None
        self.scan = Canvas(*GRID)
        circuit_overload(self.scan, SCAN_OFF - .002, .74)
        self.ecg_start = pulse_canvas(OUTRO)
        self.outro = pulse_canvas(POWER_OFF - 1 / FPS)

    def energy(self, time):
        frame = self.bands[max(0, min(len(self.bands) - 1, round(time * FPS)))]
        return tuple(value / 63 for value in frame)

    def flash_at(self, time):
        if BURST <= time < DROP_START:
            return None
        if DROP_START <= time < DROP_START + .38:
            time -= DROP_START - BURST
        event = bisect_right(self.event_times, time) - 1
        if event < 0:
            return None
        start, index, _, raw = self.events[event]
        lifetime = .38 if raw else .32
        age = time - start
        if age >= lifetime:
            return None
        first_start, first_end = CHORUSES[0]
        dissolve = ease((age - lifetime + .155) / .155) if first_start <= start < first_end else 0.0
        return self.assets["flashes"][index], dissolve

    def special_scene(self, canvas, time, bass, columns, cue):
        release = release_at(time)
        if release:
            fit(canvas, self.stage(SLICE_START, bass, columns, cue))
        paint_character(canvas, self.assets["special"], time, bass,
                        foreground=bool(release), dissolve=release)
        if not release:
            paint_later_details(canvas, time, "fault", "", columns, 1 - (time - GLITCH_START) / 3)
        paint_errors(canvas, time)

    def stage_details(self, canvas, time, columns):
        if OUTRO <= time < POWER_OFF:
            phase = (time - OUTRO) / (ZERO - OUTRO)
            paint_ecg_details(canvas, phase, hit(time, PIANO_KEYS, .27))
            return
        if time >= OUTRO or BURST <= time < DROP_START or SCAN_OFF <= time < END:
            return

        kind = ""
        if time < GLITCH_START:
            mode, beats = "current", FIRST_DRIVER
        elif time < SCAN_OFF:
            mode, beats = "pressure", self.triggers
        elif time >= DROP_START:
            mode, beats = "climax", SECOND_DRIVER
        else:
            index = bisect_right(self.cuts, time) - 1
            kind = SHOTS[index].scene
            if kind == "gate":
                return
            mode, beats = ("controls", BUILD_BEATS) if time >= BUILD_BEATS[0] else ("instrument", self.triggers)
        paint_later_details(canvas, time, mode, kind, columns, hit(time, beats, .22))

    def paint_flash(self, canvas, time, bass):
        flash = self.flash_at(time)
        if flash is None:
            return
        grid, dissolve = flash
        if time < OUTRO:
            paint_character(canvas, grid, time, bass, foreground=True, dissolve=dissolve)
            return
        portrait = Canvas(canvas.w, canvas.h)
        paint_character(portrait, grid, time, bass, strength=.66)
        # Keep graph strokes, lettering and their blank backing intact.
        for row, art in zip(canvas.cells[:-1], portrait.cells[:-1]):
            for x, mark in enumerate(row):
                if mark == (" ", DIM) and art[x][0] != " ":
                    row[x] = art[x]

    def solo(self, index, time, start, bass):
        grid = self.assets["solos"][str(index)]
        canvas = Canvas(*GRID)
        mouth_x, mouth_y = grid["mouth"]
        mouth = (mouth_x, mouth_y, jaw_at(time - start, VOCALS[index], bass))
        paint_art(canvas, grid["map"], 17 if index == 38 else 22, 0, 70, canvas.h,
                  time, blink=mouth)
        return canvas

    def wipe(self, time):
        canvas = Canvas(*GRID)
        edge = (canvas.w + 28) * (time - SCAN_OFF) / (SCAN_BLACK - SCAN_OFF) - 4
        for y, row in enumerate(self.scan.cells):
            line = max(-2, min(canvas.w + 1, round(edge - y * .35)))
            for x in range(max(0, line + 2), canvas.w):
                canvas.cells[y][x] = row[x]
            canvas.put(line, y, "/" if y % 3 else "1", RED_EDGE)
        return canvas

    def monitor_off(self, time):
        canvas = Canvas(*GRID)
        if time >= BLACK:
            return canvas
        amount = (time - POWER_OFF) / (BLACK - POWER_OFF)
        if amount < .65:
            height = max(1, round(canvas.h * (1 - ease(amount / .65))))
            top = (canvas.h - height) // 2
            for y in range(height):
                canvas.cells[top + y] = self.outro.cells[y * canvas.h // height]
        else:
            extent = max(1, round(canvas.w * (1 - ease((amount - .65) / .35))))
            canvas.center(canvas.h // 2, "-" * extent if extent > 2 else "+", BLUE)
        return canvas

    def stage(self, time, bass, columns, cue):
        if SCAN_BLACK <= time < RETURN or CLEAR <= time < DROP_START:
            return Canvas(*GRID)
        if SCAN_OFF <= time < SCAN_BLACK:
            return self.wipe(time)
        if RETURN <= time < REENTRY:
            return restart_canvas(time, bass)
        if START <= time < SCAN_OFF:
            return pressure_canvas(max(time, SLICE_START), bass)
        if time >= POWER_OFF:
            return self.monitor_off(time)
        if time >= OUTRO:
            return pulse_canvas(time)

        index = max(0, bisect_right(self.cuts, time) - 1)
        start = self.cuts[index]
        if index in SOLOS:
            return self.solo(index, time, start, bass)
        end = self.cuts[index + 1] if index + 1 < len(SHOTS) else OUTRO
        canvas, _ = compose_stage(time, bass, columns, index, start, end, cue, self.triggers, self.layers.draw)
        if REENTRY <= time < END:
            gain = ease((time - REENTRY) / (END - REENTRY - .12))
            restart = restart_canvas(time, .45)
            for y, row in enumerate(canvas.cells):
                for x in range(canvas.w):
                    if hash16(x * 541 + y * 211) / 65535 > gain:
                        row[x] = restart.cells[y][x]
        return canvas

    def green_flash(self, canvas, time):
        beat = bisect_right(self.green, time) - 1
        if beat < 0 or time - self.green[beat] >= .125:
            return
        seed = hash16(beat * 481 + 711)
        count = 9 + seed % 6
        x = seed % 10 + 2 if beat % 2 else canvas.w - count - 3 - seed % 10
        y = 2 + seed % max(1, canvas.h - 10)
        canvas.put(x, y, "".join(CODE[(seed + i * 7) & 15] for i in range(count)), GREEN)

    def subtitles(self, canvas, english):
        if not english:
            return
        chinese = self.translations.get(english)
        lines = [(line, WHITE) for line in wrap(english, canvas.w - 8)]
        if chinese:
            lines.extend((line, NORMAL) for line in wrap(chinese, canvas.w - 8))
        start = canvas.h - 2 - len(lines)
        for index, (words, style) in enumerate(lines):
            length = text_width(words)
            left = (canvas.w - length) // 2
            canvas.put(max(0, left - 2), start + index, " " * (length + 4), DEEP)
            canvas.put(left, start + index, words, style)

    def render(self, time, w, h, paused=False, offset=0.0, help_on=False, ready=False, *, window_size=None):
        canvas = TerminalCanvas(w, h)
        size = "K AUTO" if window_size is None else f"K {window_size[0]}x{window_size[1]}"
        if w < 56 or h < 20:
            canvas.center(max(0, h // 2 - 1), "CYBERNETIC", BRIGHT)
            canvas.center(max(0, h // 2 + 1), "Enlarge window", WHITE)
            canvas.center(h - 1, f"{size}   Q quit", CONTROL_INK)
            return canvas
        if ready:
            if self.cover_cache is None or self.cover_cache[0] != (w, h):
                title_cover(canvas, self.assets["portraits"][2])
                self.cover_cache = ((w, h), canvas.cells[:-1])
            canvas.cells[:-1] = self.cover_cache[1]
        else:
            lyric_time = time + offset
            cue = cue_at(self.lyrics, self.lyric_times, lyric_time)
            columns = self.energy(time)
            bass = sum(columns[:6]) / 6
            if DRUM_START <= time < OPEN_END:
                self.drum_montage.draw(canvas, time)
            elif time < OPEN_END:
                paint_opening(canvas, time, self.opening_cues, bass, columns)
                self.green_flash(canvas, time)
                self.paint_flash(canvas, time, bass)
            elif GLITCH_START <= time < GLITCH_END:
                self.special_scene(canvas, time, bass, columns, cue)
            elif TEAR_PEAK <= time < OUTRO:
                incoming = None
                if time >= TEAR_RELEASE:
                    incoming = Canvas(w, h)
                    fit(incoming, self.ecg_start)
                    paint_ecg_details(incoming, 0, 0)
                paint_signal_tear(canvas, time, bass, incoming)
            else:
                fit(canvas, self.stage(time, bass, columns, cue))
                if LOG_START <= time < GLITCH_START:
                    paint_instruments(canvas, time)
                idle_panel = None
                if DROP_START <= time < OUTRO:
                    idle_panel = paint_finale(canvas, time, bass, lyric_time, cue)
                if idle_panel is not None:
                    box, widest_left = idle_panel
                    paint_idle(canvas, self.assets["idle_portrait"], time, box, widest_left)
                    paint_signal_tear(canvas, time, bass)
                    self.stage_details(canvas, time, columns)
                else:
                    if time < OUTRO:
                        self.stage_details(canvas, time, columns)
                    if not (SCAN_BLACK <= time < RETURN or CLEAR <= time < DROP_START):
                        self.green_flash(canvas, time)
                    self.paint_flash(canvas, time, bass)
                    if time >= OUTRO:
                        self.stage_details(canvas, time, columns)
            if time < OUTRO:
                self.subtitles(canvas, cue[0])
        if help_on:
            info = "[ ] lyric offset    K window size    1-5 chapters"
            canvas.put(0, h - 3, " " * w, DEEP)
            canvas.center(h - 3, info, CONTROL_INK)
        controls = f"{CONTROLS}   {size}"
        if text_width(controls) > w:
            controls = f"SPACE pause  <- -> 5s  Q quit  {size}"
        canvas.center(h - 1, controls, CONTROL_INK)
        return canvas


if __name__ == "__main__":
    if sys.platform != "win32":
        raise SystemExit("Run Play.cmd in a Windows command prompt.")
    import player_win

    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding="utf-8")
    sys.exit(player_win.main(film_factory=TerminalFilm, description="Cybernetic terminal MV"))
