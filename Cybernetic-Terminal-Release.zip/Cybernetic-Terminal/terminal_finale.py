"""Beat-driven side panels and a protected lyric area for the final chorus."""
from functools import lru_cache

from climax_layers import SECOND_DRIVER, hit
from cybernetic import ease
from player import BRIGHT, FONT
from terminal_timing import IDLE_START
from visual_variation import BLUE, DEEP, frame_clock


PANEL_DARK, PANEL_MID, PANEL_EDGE = 37, 38, 39
LYRIC_RED, LYRIC_SHADOW = 40, 41

# A narrower display face keeps CYBERNETIC together in an 80-column window.
COMPACT = {
    "A": ("010", "101", "111", "101", "101"),
    "B": ("110", "101", "110", "101", "110"),
    "C": ("011", "100", "100", "100", "011"),
    "D": ("110", "101", "101", "101", "110"),
    "E": ("111", "100", "110", "100", "111"),
    "F": ("111", "100", "110", "100", "100"),
    "G": ("011", "100", "101", "101", "011"),
    "H": ("101", "101", "111", "101", "101"),
    "I": ("111", "010", "010", "010", "111"),
    "J": ("001", "001", "001", "101", "010"),
    "K": ("101", "101", "110", "101", "101"),
    "L": ("100", "100", "100", "100", "111"),
    "M": ("101", "111", "111", "101", "101"),
    "N": ("110", "101", "101", "101", "101"),
    "O": ("010", "101", "101", "101", "010"),
    "P": ("110", "101", "110", "100", "100"),
    "Q": ("010", "101", "101", "010", "001"),
    "R": ("110", "101", "110", "101", "101"),
    "S": ("011", "100", "010", "001", "110"),
    "T": ("111", "010", "010", "010", "010"),
    "U": ("101", "101", "101", "101", "111"),
    "V": ("101", "101", "101", "101", "010"),
    "W": ("101", "101", "111", "111", "101"),
    "X": ("101", "101", "010", "101", "101"),
    "Y": ("101", "101", "010", "010", "010"),
    "Z": ("111", "001", "010", "100", "111"),
    ".": ("0", "0", "0", "0", "1"),
    ",": ("0", "0", "0", "1", "1"),
    "'": ("1", "1", "0", "0", "0"),
    " ": ("00",) * 5,
}
WIDE = {**FONT, "'": ("1", "1", "0", "0", "0"), ",": ("0", "0", "0", "1", "1"),
        " ": ("000",) * 5, ".": ("0", "0", "0", "0", "1")}


def block_width(text, font):
    return sum(len(font.get(char, font[" "])[0]) + 1 for char in text) - 1


def wrap_blocks(words, room, font):
    lines = []
    line = ""
    for word in words:
        proposed = f"{line} {word}" if line else word
        if line and block_width(proposed, font) > room:
            lines.append(line)
            line = word
        else:
            line = proposed
    if line:
        lines.append(line)
    return lines


@lru_cache(maxsize=64)
def lyric_pages(lyrics, room, max_lines):
    words = lyrics.upper().replace("’", "'").rstrip(".!?").split()
    for font in (WIDE, COMPACT):
        lines = wrap_blocks(words, room, font)
        if len(lines) <= max_lines and all(block_width(line, font) <= room for line in lines):
            return ((tuple(lines), font),)
    # In a short terminal, cycle through chunks of the same sung line.
    return tuple((tuple(lines[i:i + max_lines]), COMPACT) for i in range(0, len(lines), max_lines))


def block_points(text, font):
    left = 0
    points = []
    for char in text:
        rows = font.get(char, font[" "])
        for row, pattern in enumerate(rows):
            for col, bit in enumerate(pattern):
                if bit == "1":
                    points.append((left + col, row))
        left += len(rows[0]) + 1
    return tuple(points)


def block_word(canvas, text, font, y):
    left = (canvas.w - block_width(text, font)) // 2
    points = block_points(text, font)
    for x, top in points:
        canvas.put(left + x + 1, y + top + 1, "▒", LYRIC_SHADOW)
    for x, top in points:
        canvas.put(left + x, y + top, "█", LYRIC_RED)


def paint_panels(canvas, time, edge, attack, top, bottom):
    width = canvas.w
    beat_shift = int(time * 4)
    for y in range(top, bottom + 1):
        band = (y - top) // 4
        row = canvas.cells[y]
        for x in range(edge):
            stripe = (x // 3 + band + beat_shift % 3) % 6
            tone = PANEL_MID if stripe in (1, 2) else PANEL_DARK
            mark = "▓" if stripe in (1, 2, 3) else "░"
            if x == edge - 1:
                tone, mark = (PANEL_EDGE if attack > .4 else PANEL_MID), "│"
            elif x + 3 >= edge and attack > .4:
                tone, mark = PANEL_EDGE, "▒"
            row[x] = (mark, tone)
            row[width - x - 1] = (mark, tone)
    line = "─" * max(0, width - 2 * edge - 2)
    for y in (top - 1, bottom + 1):
        canvas.put(edge, y, "+" + line + "+", PANEL_MID)


def paint_finale(canvas, time, bass, lyric_time, cue):
    words, _, start, end = cue
    width, height = canvas.w, canvas.h
    top, bottom = max(4, (height + 15) // 19 + 1), height - 8
    limit = min(round(width * .225), max(2, (width - 50) // 2))
    resting_edge = min(limit, max(2, round(width * .105)))
    attack = hit(time, SECOND_DRIVER, .28)
    edge = resting_edge + round((limit - resting_edge) * ease(attack) * (.82 + .18 * bass))
    room = width - 2 * limit - 4
    for y in range(top):
        canvas.put(0, y, " " * width, DEEP)
    canvas.put(2, 1, "CYBERNETIC", BRIGHT)
    clock = frame_clock(time)
    canvas.put(width - len(clock) - 2, 1, clock, BLUE)
    paint_panels(canvas, time, edge, attack, top, bottom)

    # Quiet the small code. Its original motion remains in the shallow lanes
    # above and below the central headline and under the side panels.
    for y in range(top, bottom + 1):
        row = canvas.cells[y]
        for x in range(edge, width - edge):
            char, _ = row[x]
            if char != " ":
                row[x] = (char, BLUE if (x + y * 5) % 7 == 0 else DEEP)
    if time >= IDLE_START:
        left, right = edge + 2, width - edge - 3
        for y in range(top + 1, bottom):
            canvas.put(left, y, " " * (right - left + 1), DEEP)
        return (left, top + 1, right, bottom - 1), resting_edge + 2
    if not words:
        return
    available = bottom - top + 1
    max_lines = 2 if available >= 12 else 1
    pages = lyric_pages(words, room, max_lines)
    span = min(5.6, end - start) if end - start > 9 else end - start
    phase = min(.999, max(0.0, (lyric_time - start) / max(.001, span)))
    lines, font = pages[int(phase * len(pages))]
    line_step = 7
    total = len(lines) * line_step - 2
    y = top + (available - total) // 2
    left, right = edge + 1, width - edge - 1
    for row in range(max(top, y - 1), min(bottom + 1, y + total + 2)):
        canvas.put(left, row, " " * (right - left), DEEP)
    for i, words in enumerate(lines):
        block_word(canvas, words, font, y + i * line_step)
