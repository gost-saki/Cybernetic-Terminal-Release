@echo off
setlocal
cd /d "%~dp0"
set "PLAYER_PYTHON=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not exist "%PLAYER_PYTHON%" set "PLAYER_PYTHON=python.exe"
"%PLAYER_PYTHON%" -B "%~dp0terminal_film.py" --fps 24 %*
if errorlevel 1 pause
