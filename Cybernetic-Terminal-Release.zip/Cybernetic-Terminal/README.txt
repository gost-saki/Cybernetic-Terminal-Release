﻿CYBERNETIC · 终端 MV / TERMINAL MV
创意指导 / Creative direction — Shanyce

中文版

安装与播放
  1. 在 Windows 10 或 11 上完整解压工程。
  2. 安装 Python 3.9 或更高版本。安装时勾选 “Add Python to PATH”。
     Python 3.9.13 官方安装页
     https://www.python.org/downloads/release/python-3913/
     在 Files 下选择适合系统的 Windows installer，多数电脑选 64-bit。
     也可以在这里下载新版 Python
     https://www.python.org/downloads/windows/
  3. 双击 Play.cmd，等封面出现后按空格。字符画在终端实时绘制，声音由
     Windows 播放工程里的 WAV。正常播放只用 Python 标准库，可离线运行。

播放器以自适应模式启动。按 K 循环切换自适应 → 96×28 → 120×38 → 160×48
→ 自适应，单位为列 × 行。进入自适应后，画面随当前窗口大小实时调整。
选固定档位时，若终端限制窗口调整，画面会在现有窗口内居中排版。
若双击后找不到 Python，在新打开的
命令提示符运行 python --version，确认 Python 已加入 PATH。若中文显示为
方块，可在 Windows Terminal 中换用支持中文的字体。没有可用的音频设备时，
从工程目录运行 Play.cmd --silent 可观看无声版。

操作
  空格 / Enter    开始、暂停或继续
  左 / 右         后退 / 前进 5 秒
  R               从头播放
  Q / Esc         退出
  H               切换按键提示
  K               循环切换自适应、小、中、大
  1–5             跳到开场、第一段高潮、ERROR、第二段高潮、心电图片尾
  [ / ]           字幕提前 / 延后 0.1 秒
  , / .           上一句 / 下一句歌词
  + / -           调整音量

从指定秒数开始，例如在工程目录运行 Play.cmd --start 170 --autoplay。

工程结构
  terminal_film.py              主播放器和画面合成
  terminal_opening.py           开场分镜
  drum_montage.py               52.33–58.71 秒的鼓点快切
  opening_geometry.py           开场独立构图
  opening_analysis.py           从 WAV 提取近似人声起音和低频重拍，确定开场切点
  terminal_timing.py            全片时间轴与默认字幕偏移 LYRIC_DELAY
  media/Cybernetic-Full.wav     播放音轨
  media/Cybernetic.lrc          英文字幕时间轴
  media/Cybernetic.zh.json      中文字幕
  media/terminal-assets.json.gz 播放用频谱、切点与人物字符采样

如果修改音频或角色素材，可安装 NumPy 和 Pillow，再在工程目录运行
python build_terminal_assets.py 重新生成采样。开场分镜的位置还可在
terminal_opening.py 调整。修改快切段的角色图后，运行
python build_drum_montage.py 重新生成快切采样。

署名与来源
  创意指导 Shanyce，提供视觉参考、参与角色素材选用和节奏调整，
  并给出了多轮制作反馈。鼓点快切使用 Shanyce 提供的参考图，部分原图带有
  @AbilfloridaArts 署名。
  音乐《Cybernetic》，Yunosuke × Circus-P，Hatsune Miku English 演唱
  https://yunosuke-official.bandcamp.com/album/cybernetic
  B 站视觉参考（画面构图、分镜与字符动效）
  https://www.bilibili.com/video/BV186pc65E68/
  B 站原版参考（终端播放与字符视觉）
  https://www.bilibili.com/video/BV1XtHw67En7/
  原始终端播放器工程 CoraxEldridge / world.execute-me-ascii
  https://github.com/CoraxEldridge/world.execute-me-ascii/tree/windows-support


ENGLISH

Install and play
  1. Extract the entire ZIP on Windows 10 or 11.
  2. Install Python 3.9 or newer and select “Add Python to PATH” during setup.
     Official Python 3.9.13 release and Windows installers
     https://www.python.org/downloads/release/python-3913/
     Choose the installer for your system under Files. Most PCs use 64-bit.
     Newer Windows releases are available at
     https://www.python.org/downloads/windows/
  3. Double-click Play.cmd and press Space on the cover screen. The terminal
     draws the animation live while Windows plays the project's WAV. Playback
     works offline and uses only the Python standard library.

Playback starts in Auto. Press K to cycle Auto → 96×28 → 120×38 → 160×48
→ Auto (columns × rows). In Auto, the picture follows the current terminal
size as you resize it. If the terminal cannot resize for a preset, the player
centers the chosen layout in the available space. If Play.cmd cannot find Python, run python --version in a fresh Command Prompt to confirm it is
on PATH. If Chinese characters appear as boxes, try a Windows Terminal font
with Chinese glyph support. Without an audio device, run Play.cmd --silent
from the project folder.

Controls
  Space / Enter   Start, pause, or resume
  Left / Right    Seek backward / forward 5 seconds
  R               Restart
  Q / Esc         Quit
  H               Toggle shortcut help
  K               Cycle Auto and the three window sizes
  1–5             Opening, first climax, ERROR, second climax, or ECG outro
  [ / ]           Advance / delay subtitles by 0.1 seconds
  , / .           Previous / next lyric
  + / -           Adjust volume

To start at a specific time, run Play.cmd --start 170 --autoplay to seek 170 seconds
into the track.

Project files
  terminal_film.py              Playback and composition
  terminal_opening.py           Opening shot order
  drum_montage.py               Percussion cuts at 52.33–58.71 seconds
  opening_geometry.py           Opening compositions
  opening_analysis.py           Approximate vocal onsets and low-end drum hits from the WAV
  terminal_timing.py            Timeline and default subtitle offset (LYRIC_DELAY)
  media/Cybernetic-Full.wav     Playback audio
  media/Cybernetic.lrc          English subtitle timing
  media/Cybernetic.zh.json      Chinese subtitles
  media/terminal-assets.json.gz Spectrum, scene timing, and portrait samples

After changing the audio or character artwork, install NumPy and Pillow, then
run python build_terminal_assets.py from the project folder to rebuild sampled
assets. Edit terminal_opening.py to change the opening shot order. Run
python build_drum_montage.py after editing the montage artwork.

Credits and references
  Creative direction by Shanyce, who provided visual references, helped select
  character artwork and shape the pacing, and gave feedback throughout production.
  Shanyce supplied the montage references, some of which are signed @AbilfloridaArts.
  “Cybernetic” by Yunosuke × Circus-P, featuring Hatsune Miku English
  https://yunosuke-official.bandcamp.com/album/cybernetic
  Bilibili visual reference for framing and text-based animation
  https://www.bilibili.com/video/BV186pc65E68/
  Bilibili reference for the original terminal presentation
  https://www.bilibili.com/video/BV1XtHw67En7/
  Upstream terminal player by CoraxEldridge
  https://github.com/CoraxEldridge/world.execute-me-ascii/tree/windows-support
