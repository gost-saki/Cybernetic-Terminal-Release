"""Procedural scene primitives and subtitle timing."""
import math
import re

from cybernetic import BLUE, DEEP, FPS, VIOLET, ease, hash16
from player import BRIGHT, DIM, FONT, NORMAL, WHITE, width

TOP, BOTTOM = 5, 26

BEATS = (136.91, 137.58, 138.27, 138.72, 139.16, 140.08, 141.44, 142.46,
         143.26, 144.62, 145.54, 145.99, 146.55, 146.90, 147.35, 148.26, 149.17,
         149.97, 151.22, 151.90, 153.26, 154.17, 154.62, 155.53, 156.90, 157.34,
         157.80, 158.26, 158.71)


def clamp(v, low=0.0, high=1.0):
    return max(low, min(high, v))


def frame_clock(t):
    centis = round(t * 100)
    return f"{centis//6000:02d}:{centis//100%60:02d}.{centis%100:02d}"


def signal(canvas, x0, x1, middle, t, amplitude, style, phase=0):
    for x in range(x0, x1 + 1):
        v = math.sin(x*.19 + t*4.3 + phase) + .36 * math.sin(x*.52 - t*2.7)
        mark = "1" if x % 3 == 0 else "0" if x % 3 == 1 else "."
        canvas.put(x, middle + v * amplitude, mark, style)


def packet(canvas, x, y, width, token, tint):
    for j in range(width):
        bit = hash16(token + j * 319) & 15
        canvas.put(x + j, y, "0123456789ABCDEF"[bit], tint if j % 4 else BLUE)


def topology(canvas, t, bass, phase):
    nodes = [(12, 17), (24, 9), (38, 21), (52, 14), (65, 8), (77, 20), (94, 11)]
    for i, ((x, y), (next_x, next_y)) in enumerate(zip(nodes, nodes[1:])):
        canvas.line(x, y, next_x, next_y, ".", DEEP)
        u = (t * .8 + i * .23 + .25 * bass + .12 * phase) % 1
        canvas.put(x + u*(next_x-x), y + u*(next_y-y), "10", BRIGHT)
    for i, (x, y) in enumerate(nodes):
        canvas.put(x-1, y, f"[{i:02}]", NORMAL if (i+int(t*2)) % 4 else VIOLET)
        packet(canvas, x, y+2, 5, i*47 + int(t*3), DIM)
    canvas.put(8, 24, "> route(0, 1)", 5)


def matrix(canvas, t, bass, phase):
    tick = int(t * 4.0)
    for row in range(3):
        for col in range(4):
            x, y = 5 + col * 25, 6 + row * 7
            n = col + 4 * row
            faulty = (n + tick // 2) % 7 < 2 + int(bass * 2)
            tint = VIOLET if faulty else BLUE
            canvas.box(x, y, 23, 6, tint)
            canvas.put(x+2, y+1, f"0x{0xA0+n:02X}  " + ("CRC FAIL" if faulty else "ACK"), VIOLET if faulty else NORMAL)
            packet(canvas, x+2, y+3, 17, 1120*n + tick, tint)


def stream(canvas, t, bass, phase):
    for lane in range(16):
        origin = 5 + lane * 6
        token = hash16(lane + int(t * 2) * 7)
        speed = 4 + (lane % 5) * 2
        for k in range(15):
            y = TOP + ((token % 23 + t * speed + k) % 22)
            x = origin + 2.4 * math.sin(y * .24 + t*.8 + lane)
            col = VIOLET if (lane + k) % 9 == 0 else NORMAL if k in (0, 3) else DEEP
            canvas.put(x, y, "1" if hash16(token + k) & 1 else "0", col)
    signal(canvas, 4, 103, 17, t, 2 + bass * 1.4, BRIGHT)


def queue(canvas, t, bass, phase):
    gate = 68 + round(16 * ease(phase))
    for row in range(7, 25, 2):
        remaining = max(14, gate - 4 - round(abs(row - 16)**1.15))
        packet(canvas, 4+int((t*29+row*7)%7), row, remaining, 19*row+int(t*9), DIM if row % 4 == 1 else NORMAL)
        canvas.put(gate+4, row, f"0x{hash16(row+int(t*3)):04X}", VIOLET if row % 4 == 1 else BLUE)
    canvas.line(gate, 5, gate, 25, ":", BRIGHT)
    canvas.put(71, 26, f"> queue={max(0,92-round(78*phase)):02}", VIOLET)


def glyph_title(canvas, t, bass, phase):
    word = "CYBERNETIC"
    for i, char in enumerate(word):
        base = 10 + i*9
        for row, mask in enumerate(FONT[char]):
            y = 9 + 3*row
            wobble = round(1.4 * math.sin(t * 5 + row) * ease(phase))
            for col, active in enumerate(mask):
                if active == "1":
                    at = base + col + wobble
                    for v in range(2):
                        token = hash16(i*531 + row*71 + col*55 + v + int(t*12))
                        canvas.put(at, y+v, "01"[token & 1], VIOLET if (row+i+v) % 5 == 0 else BRIGHT)
    signal(canvas, 6, 101, 24, t, 1.2 + bass * 2.2, DIM, 2)


def memory(canvas, t, bass, phase):
    for pane in range(3):
        x = 5 + pane*34
        canvas.box(x, 6, 31, 19, VIOLET if pane == 2 else BLUE)
        name = ("INPUT BUFFER","FRAME CACHE","OUTPUT STACK")[pane]
        canvas.put(x+2, 8, name, VIOLET if pane == 2 else NORMAL)
        for row in range(7):
            k = 7 + ((row * 13 + pane * 7 + int(t*10)) % 20)
            packet(canvas, x+2, 10+row*2, k, 71*pane + row*36 + int(t*7), NORMAL if k > 20 else DIM)


def collapse(canvas, t, bass, phase):
    gap = 2 + (1-ease(phase)) * 11
    center = 16
    for i in range(17):
        y = center + (i-8)*gap/8
        spread = round(36 + 14 * math.sin(i*.49 + t) + 12*bass)
        packet(canvas, 54-spread, y, spread*2, int(t*17)+i*29, VIOLET if i % 5 == 0 else DIM)
    canvas.line(6, center, 101, center, "-", BRIGHT)


def portal(canvas, t, bass, phase):
    # Rotate a field of helical rails in perspective and draw it as moving code.
    spin = t * 1.8
    for rung in range(24, 0, -1):
        depth = .55 + ((rung/24 + t*.24) % 1) * 9.2
        radius = (34 + bass*9)/(depth + .22)
        for rail in range(12):
            angle = rail * math.tau/12 + depth*.35 + spin
            x = 54 + math.cos(angle)*radius + math.sin(depth*.7+t)*5
            y = 15 + math.sin(angle)*radius*.48
            color = VIOLET if rail % 5 == 0 else BRIGHT if depth < 2.3 else NORMAL if depth < 4.2 else DEEP
            canvas.put(x, y, "01"[hash16(rung + rail*175 + int(t*13)) & 1], color)
    signal(canvas, 6, 101, 15, t, 2 + bass*3, BLUE)


def mesh(canvas, t, bass, phase):
    for z in range(18, 0, -1):
        scale = 1.8/(1 + z*.105)
        for i in range(-24, 25):
            y = 26 - z*.96 + 2.8*math.sin(i*.26 + z*.57 - t*4.1)*(0.4+bass)*scale
            x = 54 + i*scale + math.sin(t*1.3 + z*.15)*8
            token = hash16(i*763 + z*39 + int(t*10))
            style = VIOLET if token % 8 == 0 else NORMAL if z < 8 else BLUE if z < 14 else DEEP
            canvas.put(x, y, ".01:"[token % 4], style)
    canvas.put(66, 7, "y = sin(x + z - t)", DIM)


def scope(canvas, t, bass, phase):
    canvas.line(7, 16, 100, 16, ".", DEEP)
    for index, color in enumerate((BLUE,VIOLET,NORMAL)):
        signal(canvas, 7, 100, 16, t, (index+1)*1.25 + bass, color, index*1.1)
    canvas.put(9, 24, "sample[0..95] -> phase(x)", 5)


def gate(canvas, t, bass, phase):
    reach = round(1 + 17 * ease((phase-.40)/.6))
    canvas.line(54-reach, 16, 54+reach, 16, ".", VIOLET if phase > .38 else DEEP)
    canvas.put(54, 16, "_", DIM)


def prompt(canvas, t, bass, phase):
    canvas.put(10, 12, "> " + ("reboot(0x01)" if t > 90 else "link(0, 1)"), NORMAL)
    canvas.put(10, 16, f"  0x{hash16(int(t*2)):04X}" if int(t*2)%2 else "  _", DIM)


SCENES = {
    "prompt": prompt, "topology": topology, "scope": scope, "matrix": matrix,
    "stream": stream, "queue": queue, "type": glyph_title, "memory": memory,
    "collapse": collapse, "gate": gate, "portal": portal, "mesh": mesh,
}


def lyric_entries(path):
    entries = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        match = re.fullmatch(r"\[(\d+):(\d{2}(?:\.\d+)?)\](.*)", line)
        if match:
            entries.append((60 * int(match[1]) + float(match[2]), match[3].strip()))
    return entries
