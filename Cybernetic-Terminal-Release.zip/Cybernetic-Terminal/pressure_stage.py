"""The first instrumental's pressure build, overload, and scan-out."""
from bisect import bisect_right
from functools import lru_cache
import math

from climax_layers import hit
from cybernetic import ease, hash16, shift_strip
from director_scenes import RED, strbits
from player import BRIGHT, NORMAL, WHITE, Canvas
from visual_variation import BLUE, DEEP, VIOLET


START = 77
SLICE_START = 80.005
SCAN_OFF = 89.495
BLACK = 89.92
RETURN = 90.65
REENTRY = 91.50
END = 92.80
BEATS = (
    77.130, 77.350, 77.805, 78.715, 79.170, 79.625, 80.005, 80.230,
    80.455, 80.985, 82.350, 82.805, 82.955, 83.185, 83.490, 83.715,
    83.865, 84.090, 84.620, 85.080, 85.985, 86.440,
)
ROUTES = (
    (86.440, (3, 6), (23, 6), (23, 17), (52, 17)),
    (86.895, (104, 30), (83, 30), (83, 20), (55, 20)),
    (87.280, (7, 32), (32, 32), (32, 9), (62, 9)),
    (87.500, (100, 3), (74, 3), (74, 26), (42, 26)),
    (87.730, (1, 22), (14, 22), (14, 3), (58, 3)),
    (88.260, (106, 12), (92, 12), (92, 33), (48, 33)),
    (88.500, (0, 13), (38, 13), (38, 28), (104, 28)),
    (88.715, (107, 24), (66, 24), (66, 7), (1, 7)),
    (88.945, (0, 35), (52, 35), (52, 2), (106, 2)),
)
ROUTE_BEATS = tuple(route[0] for route in ROUTES)
from terminal_timing import GRID

W, H = GRID
HEX = "0123456789ABCDEF"


def wave_gate(canvas, time, bass, attack):
    """Two diagonal scans reveal a slowly curving interference pattern."""
    age = time - START
    sweep = age / 3
    for lane in range(12):
        for x in range(2, W - 2, 2):
            u = x / W
            q = (u - (lane - 5) * .032 - sweep) % 1
            if q > .63:
                continue
            y = 5 + lane * 2.2 + 3.2 * math.sin(u * 7.8 - age * .86 + lane * .29)
            if attack > .48 and (lane < 5 or 73 < x < 95):
                x += round(9 * attack * (1 if lane % 2 else -1))
            tone = RED if q < .038 and lane in (2, 3, 8, 10) else (
                BRIGHT if q < .11 else NORMAL if q < .27 else BLUE
            )
            code = HEX[(x + lane * 3 + int(age * (7 + 8 * attack))) & 15]
            canvas.put(x, y, code, tone)
    shift = round(15 * math.sin(age * 1.74))
    canvas.line(10 + shift, 32, 71 + shift, 3, "/", VIOLET)
    canvas.line(34 - shift, 34, 92 - shift, 7, "/", RED if attack > .35 else DEEP)
    if attack > .28:
        for row in (8, 16, 24):
            shift_strip(canvas, row, 3, W - 3, round((16 if row == 16 else -10) * attack))
            canvas.put(4 + round(39 * (1 - attack)), row,
                       strbits(int(time * 240) + row, round(12 + 49 * bass), "01+:"),
                       RED if row == 16 else BRIGHT)


def sliced_frames(canvas, time, beat, attack, bass):
    """Off-beat holds alternate with discrete cuts, rotation, and tearing."""
    fast = time >= 82.35
    tick = int(time * (18 if fast else 8))
    for section in range(4):
        side = (section + beat) % 4
        shift = round(attack * (18 if fast else 11))
        x = (3, 56, 11, 47)[side] + shift * (-1 if side % 2 else 1)
        y = (4, 7, 18, 20)[side] + round(3 * math.sin(time * 3 + section))
        width = (37, 44, 29, 49)[section]
        tone = RED if section == 1 and attack > .12 else BRIGHT if section == 0 else VIOLET
        canvas.box(x, y, width, 8, tone)
        for row in range(1, 7):
            power = hash16(beat * 693 + row * 431 + section * 1301)
            length = max(3, round((width - 3) * (.22 + .69 * (power % 47) / 47)))
            drift = round(attack * ((row % 3) - 1) * 23) if fast else (row + tick) % 4
            canvas.put(x + 2 + drift, y + row,
                       strbits(power + tick * (row + 1), length, "0/1X*("),
                       tone if row % 3 == 1 else BLUE)
    for strand in range(4 + round(8 * attack)):
        row = 3 + (beat * 7 + strand * 5) % 32
        length = (16 if fast else 9) + round(54 * max(bass * .35, attack))
        left = (strand * 23 + beat * 13 + tick) % (W - length)
        canvas.put(left, row, strbits(strand * 619 + tick * 5, length, "0_1#"),
                   RED if strand % 4 == 0 else NORMAL)
    if fast and attack > .36:
        for row in range(4 + beat % 4, H - 2, 5):
            offset = round(attack * (25 if (row + beat) % 2 else -25))
            shift_strip(canvas, row, 1, W - 1, offset)
            edge = 2 if offset > 0 else W - 12
            canvas.put(edge, row, strbits(row + tick * 31, 9, "!x0/1"), RED)


def held_charge(canvas, time, attack):
    age = time - 84.09
    spread = 11 + age * 13
    tick = int(age * 9)
    for lane in range(7):
        y = 7 + lane * 4
        start = W / 2 - spread + math.sin(age * 2.15 + lane * .81) * 13
        width = round(18 + spread * 1.18 + 18 * attack)
        for k in range(0, width, 2):
            arch = math.sin(math.pi * k / width) * (1.7 + attack)
            offset = arch * (1 if lane % 2 else -1)
            tint = BRIGHT if k % 10 == 0 else VIOLET if lane % 2 else NORMAL
            canvas.put(start + k, y + offset, HEX[(tick + lane + k) & 15], tint)
        needle = start + width * ((age * .35 + lane * .185) % 1)
        canvas.put(needle, y, ">>" if lane % 2 else "<<", RED)
        canvas.put(start - 4, y, "[", RED if attack > .25 else BLUE)
        canvas.put(start + width, y, "]", BRIGHT if attack > .4 else BLUE)
    if attack > .20:
        y = 8 + (tick * 7) % 22
        canvas.put(10, y, strbits(tick * 1721, 86, "<012>:"), RED)
    filled = round(14 * ease(age / (ROUTE_BEATS[0] - 84.09)))
    for side in (5, W - 22):
        canvas.put(side, 33, "[" + "1" * filled + "." * (14 - filled) + "]",
                   RED if filled >= 10 or attack > .35 else BLUE)


@lru_cache(maxsize=1)
def overload_cells():
    return tuple(
        (x, y, hash16(1351 + x * 963 + y * 1529))
        for y in range(H) for x in range(W)
    )


def circuit_overload(canvas, time, bass):
    count = bisect_right(ROUTE_BEATS, time)
    attack = hit(time, ROUTE_BEATS, .19)
    tick = int(time * 22)
    if count < 5:
        # Faint banks survive the cut from the charge coils. Signals flare
        # these registers as the circuit extends outwards, before overflow.
        for bank in range(8):
            x = 4 + 25 * (bank % 4)
            y = 8 if bank < 4 else 24
            active = bank % 4 < count
            tone = RED if active and attack > .45 and bank % 4 == count - 1 else BLUE
            canvas.put(x, y, f"[{bank:02X}]--[" + ("1" if active else "0") + "]", tone)
            for row in (1, 2, 3):
                if active or row == 1:
                    token = bank * 211 + row * 17 + (tick if active else 0)
                    canvas.put(x + row, y + row, strbits(token, 13, "0:101."),
                               tone if active else DEEP)

    if count >= 3:
        # Each arriving gate opens another memory bank. It continues filling
        # between impacts so the last held frame spans the whole grid.
        age = time - ROUTE_BEATS[count - 1]
        fullness = min(1, (count - 3 + ease(age / .27)) / (len(ROUTE_BEATS) - 3))
        red_cells = 3 if fullness > .66 else 2
        for x, y, seed in overload_cells():
            # Traces reach the corners before the center banks saturate.
            path = abs(x / (W - 1) - .5) + abs(y / (H - 1) - .5)
            threshold = .70 * (seed % 100 / 100) + .30 * (1 - path)
            if threshold > fullness * (.96 + attack * .12):
                continue
            signal = (seed + tick * (3 + y % 4) + x * int(time)) & 63
            tone = RED if signal % 13 < red_cells else (
                WHITE if signal == 0 and attack > .35 else NORMAL if signal < 15
                else VIOLET if signal < 31 else BLUE
            )
            canvas.put(x, y, HEX[signal & 15], tone)

    for index, (at, *corners) in enumerate(ROUTES[:count]):
        age = time - at
        pulse = age * 11
        segment = pulse % (len(corners) - 1)
        current = int(segment)
        for j, ((x0, y0), (x1, y1)) in enumerate(zip(corners, corners[1:])):
            tone = RED if j == current and (index == count - 1 or index % 3 == 0) else (
                BRIGHT if j == current else NORMAL if age < .36 else VIOLET
            )
            canvas.line(x0, y0, x1, y1, "=" if y0 == y1 else ":", tone)
            if j == current:
                p = segment - j
                canvas.put(x0 + (x1 - x0) * p, y0 + (y1 - y0) * p, "0x", WHITE)
        x, y = corners[-1]
        arrived = pulse >= len(corners) - 1
        tone = RED if arrived and (time >= 88.26 or age < .41) else NORMAL
        canvas.box(x - 4, y - 1, 9, 3, tone)
        if arrived:
            canvas.put(x - 3, y, f"{index + 1:02X}:{round(bass * 99):02}", tone)
            if age < .41:
                canvas.line(x - 9, y + 2, x + 9, y + 2, "<", RED)
        elif index == count - 1:
            canvas.put(x - 2, y, "....", BRIGHT)


def pressure_canvas(time, bass):
    canvas = Canvas(W, H)
    attack = hit(time, BEATS, .17)
    if time < SLICE_START:
        wave_gate(canvas, time, bass, attack)
    elif time < 84.09:
        sliced_frames(canvas, time, bisect_right(BEATS, time), attack, bass)
    elif time < ROUTE_BEATS[0]:
        held_charge(canvas, time, attack)
    else:
        circuit_overload(canvas, time, bass)
    if time < ROUTE_BEATS[0]:
        timecode = f"01:{time - 60:05.2f}"
        canvas.put(2, 1, "CYBERNETIC", BRIGHT)
        canvas.put(W - 12, 1, timecode, BLUE)
    return canvas

def restart_canvas(time, bass):
    canvas = Canvas(W, H)
    power = ease((time - RETURN) / (REENTRY - RETURN))
    span = round(3 + power * 23)
    canvas.center(18, "-" * span, BLUE)
    canvas.put(W // 2 + span // 2, 18, "_", RED if time < 91.05 else NORMAL)
    if time > 91.20:
        canvas.center(20, ">" + "." * round(6 * bass), VIOLET)
    return canvas
