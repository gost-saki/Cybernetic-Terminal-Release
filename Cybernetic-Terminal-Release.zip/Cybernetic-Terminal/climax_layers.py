"""Audio-reactive overlays for Cybernetic's intro, pressure build, and drops."""
from bisect import bisect_right
from functools import lru_cache
import math

from statistics import fmean

from cybernetic import hash16, ease
from director_scenes import RED, strbits
from player import BRIGHT, NORMAL, WHITE, FONT
from visual_variation import BLUE, DEEP, VIOLET


INTRO_BEATS=(17.18,17.775,18.265,18.740,19.130,19.655,20.080,20.460)
INTRO_LOCK=20.630
INTRO_RELEASE=22.580
BUILD_BEATS=(
    136.205,136.670,137.125,137.355,137.810,138.265,138.720,139.145,
    139.625,140.080,140.540,140.990,141.425,141.900,142.355,142.810,
    143.260,143.715,144.170,144.625,145.080,145.535,145.990,146.215,
    146.445,146.670,146.895,147.125,147.350,147.580,147.805,148.035,
    148.260,148.490,148.715,148.940,149.170,149.700,149.965,150.415,
    150.755,151.105,
)
BURST=151.220
CLEAR=151.425
DROP_START=151.555
FIRST_DRIVER=(58.715,58.945,59.170,59.520,59.850,60.025,60.535,61.140,
              61.365,61.895,62.275,62.805,64.620,65.220,65.460,65.680,
              65.910,66.440,67.805,68.410,68.640,69.170,69.545,70.075,71.895)
SECOND_DRIVER=(151.555,151.895,153.715,153.940,154.170,154.395,154.630,155.530,
               157.350,158.205,158.620,159.170,160.985,161.895,162.805,163.260,
               164.625,165.860,166.440,168.260,168.715,168.940,169.175,170.080,
               171.895,172.815,173.260,173.715,173.945,174.170,175.530,175.985,
               176.445,179.170)
RED_BEATS=(18.475,20.460,22.580,26.670,34.25,38.620,45.08,47.320,50.530,
           54.180,56.445,58.490,58.715,60.025,61.365,62.275,65.680,68.640,
           69.545,70.075,76.820,84.620,94.10,103.41,111.90,120.72,130.10,
           136.205,139.145,141.425,143.715,145.535,146.895,148.260,148.940,
           149.965,150.415,151.105,151.220,151.555,151.895,154.170,155.530,
           159.170,164.625,166.440,168.715,169.175,170.080,173.715,175.985,
           176.445,179.170)
FILL_EVENTS=((45.080,47.320,"spill"),(98.720,100.160,"overwrite"),
             (145.535,146.445,"crowd"),(173.715,174.170,"frame"),
             (175.985,176.445,"crush"),(178.945,179.750,"drain"))
W,H=108,38
X0,X1=1,107
Y0,Y1=4,29
CHARS="0123456789ABCDEF"
BITS="01:0#1+0"


def hit(time,beats,width=.23):
    index=bisect_right(beats,time)-1
    if index<0:
        return 0.0
    phase=(time-beats[index])/width
    return max(0.0,1-phase)**1.52 if phase<=1 else 0.0


def fade(time,start,end,fraction=.24):
    size=end-start
    return max(0,min(1,(time-start)/(size*fraction),(end-time)/(size*fraction)))


def cell(index,tick,pattern):
    return pattern[hash16(index+tick*461)%len(pattern)]


def erase(c,y0=Y0,y1=Y1):
    for row in range(y0,y1):
        c.put(0,row," "*c.w,DEEP)


def digits(c,fill,time,style="overflow",red=0.0):
    """Fill in a selected order, so each burst has a different movement."""
    tick=int(time*15)
    for y in range(Y0,Y1):
        line=[]
        for x in range(X0,X1):
            r=hash16(x*933+y*2517+179)/65535
            xx=abs(x-54)/54
            yy=abs(y-16)/13
            if style=="spill":
                place=(Y1-1-y)/(Y1-Y0)*.67+r*.33
            elif style=="overwrite":
                place=(x-X0)/(X1-X0)*.72+r*.28
            elif style=="frame":
                place=(1-max(xx,yy))*.64+r*.36
            elif style=="crush":
                place=max(xx,yy)*.48+r*.52
            elif style=="drain":
                place=(y-Y0)/(Y1-Y0)*.56+r*.44
            else:
                place=(.48*xx+.29*yy)+r*.23 if style=="overflow" else r
            if place<fill:
                v=hash16(x*1943+y*267+tick*411)
                tone=(RED if red>.22 and v%17==0 else BRIGHT if v%31==0 and fill>.72
                      else VIOLET if v%15<3 else NORMAL if v%9==0 else BLUE)
                line.append((x,y,CHARS[v&15],tone))
        for x,y,ch,tone in line:
            c.put(x,y,ch,tone)


@lru_cache(maxsize=1)
def title_cells():
    # Build one 5x5 mask from the project's existing character font.
    word="CYBERNETIC"
    sx,sy=1,3
    width=(len(word)*6-1)*sx
    x0=(W-width)//2
    coords=[]
    for i,ch in enumerate(word):
        for row,bits in enumerate(FONT[ch]):
            for col,on in enumerate(bits):
                if on=="1":
                    for dy in range(sy):
                        coords.append((x0+(i*6+col)*sx,8+row*sy+dy))
    return tuple(coords)


def opening(c,time):
    if not INTRO_BEATS[0]<=time<23.02:
        return False
    count=bisect_right(INTRO_BEATS,time)
    strength=hit(time,INTRO_BEATS,.19)
    red=hit(time,RED_BEATS,.22)
    if time<INTRO_LOCK:
        fill=min(1,.16*count+.12*strength)
        digits(c,fill,time,red=red)
        if strength>.48:
            c.put(0,5+count%21,"=0/"*35,RED if red>.35 else BRIGHT)
        return True

    settle=ease((time-INTRO_LOCK)/.60)
    release=ease((time-INTRO_RELEASE)/.44)
    erase(c)
    residue=(1-settle)*.91+.13*(1-release)
    digits(c,residue,time,red=red)
    tick=int(time*14)
    for i,(x,y) in enumerate(title_cells()):
        n=hash16(i*419+1768)
        start_x=1+n%106
        start_y=4+(n//113)%25
        target_x=start_x+(x-start_x)*settle+(x-54)*release*.63
        target_y=start_y+(y-start_y)*settle+(y-15)*release*.62
        if release>.03 and n%111<release*100:
            continue
        tone=WHITE if settle>.92 and release<.12 and i%7==0 else RED if red>.33 and i%13==0 else BRIGHT
        c.put(target_x,target_y,cell(i,tick,BITS),tone)
    return True


@lru_cache(maxsize=1)
def device_slots():
    # Centre-first layout, growing outward in successive rings.
    return tuple(sorted(((x,y) for y in range(6) for x in range(7)),
                        key=lambda p:(max(abs(p[0]-3),abs(p[1]-2.5)),
                                      math.atan2(p[1]-2.5,p[0]-3))))


def coupler_boxes(c,time,count,energy,red):
    slots=device_slots()
    tick=int(time*12)
    loading=count/len(BUILD_BEATS)
    if loading>.39:
        digits(c,min(.88,(loading-.39)*1.45),time,"crowd",red)
    for index,(col,row) in enumerate(slots[:count]):
        age=time-BUILD_BEATS[index]
        fired=ease(age/.09)
        load=1+round(98*loading)
        x,y=2+col*15,5+row*4
        if count<20 and index==count-1:
            x-=round(3*(1-fired))
        hot=age<.18 or index==count-1
        tone=RED if (hot and loading>.28) or (loading>.75 and (index+tick)%7==0) else BRIGHT if hot else VIOLET if index%3==0 else BLUE
        c.box(x,y,13,4,tone)
        c.put(x+2,y+1,f"N{index+1:02X} {load:02d}%",tone if hot else NORMAL)
        width=1+round((energy*.35+loading*.55)*9)
        c.put(x+2,y+2,strbits(tick+index*171,width,"01-"),RED if hot and loading>.67 else NORMAL if hot else BLUE)
        if index>0:
            before=slots[index-1]
            px,py=2+before[0]*15+6,5+before[1]*4+1
            nx,ny=x+6,y+1
            p=(time*4+index*.37)%1
            if count<23:
                c.line(px,py,nx,ny,".",VIOLET if hot else DEEP)
            c.put(px+(nx-px)*p,py+(ny-py)*p,"+",BRIGHT if hot else BLUE)
    if loading>.91:
        for row in (4,28):
            c.put(1,row,strbits(tick+row,105,"01#X+="),RED if red>.20 else BRIGHT)


def explosion(c,time):
    erase(c)
    phase=min(1,(time-BURST)/(CLEAR-BURST))
    power=(1-phase)**.7
    tick=int(time*26)
    for i in range(round(650*power)):
        n=hash16(3011+i*307)
        sx=1+n%106
        sy=4+(n//113)%25
        spread=.9+4.6*ease(phase)
        x=54+(sx-54)*spread
        y=16+(sy-16)*spread
        if X0<=x<X1 and Y0<=y<Y1:
            tone=WHITE if phase<.18 and i%7==0 else RED if i%3==0 else BRIGHT if i%5==0 else VIOLET
            c.put(x,y,cell(i,tick,"01:#%"),tone)
    if phase<.54:
        for branch in range(8):
            p=branch*math.tau/8
            for length in range(1,19):
                x=54+length*(2+3*phase)*math.cos(p)
                y=16+length*(.51+phase)*math.sin(p)
                c.put(x,y,"+" if length%3 else "0",RED if length%4 else WHITE)


def prelude(c,time,energy):
    if not BUILD_BEATS[0]<=time<DROP_START:
        return False
    if time>=BURST:
        if time<CLEAR:
            explosion(c,time)
        else:
            erase(c)
        return True
    count=bisect_right(BUILD_BEATS,time)
    recent=hit(time,BUILD_BEATS,.22)
    red=hit(time,RED_BEATS,.20)
    if count<9:
        # Leave the handoff space readable during the first sparse beats.
        erase(c,6,26)
    coupler_boxes(c,time,count,max(recent,energy*.62),red)
    if count>=37 and recent>.30:
        c.put(1,4,strbits(int(time*150),105,"011X+=!"),RED)
    return True


def packet_line(c,x0,y0,x1,y1,phase,tone,step):
    c.line(x0,y0,x1,y1,"." if step%2 else ":",tone)
    p=phase%1
    c.put(x0+(x1-x0)*p,y0+(y1-y0)*p,strbits(step,3,"01"),BRIGHT)


def water_interactions(c,s,bands,attack,red):
    time=s.t
    bass,mid,high=bands
    tick=int(time*18)
    near=math.sin(time*1.8)
    quantity=round(6+mid*4+attack*7)
    # Floating probes light up as passing packets touch their expanding ripples.
    for k in range(quantity):
        seed=hash16(947+k*373)
        y=4+(seed//173)%22
        x=(seed%105+time*(8+k%4))%106
        spread=2+(k%3)+attack*5+bass*2
        y+=math.sin(time*2+k)*1.8
        stream=math.sin(time*4.1+k*.71)
        for a in range(12):
            theta=math.tau*a/12
            xx=x+spread*math.cos(theta)
            yy=y+spread*.45*math.sin(theta)
            tone=(RED if red>.48 and a in (2,4) and k%4==0 else NORMAL if stream>.28 else BLUE)
            c.put(xx,yy,"01"[a%2],tone)
        if k%3==0 or attack>.6:
            x2=(x+22+12*stream)%106
            y2=15+8*math.sin(k+time*1.7)
            packet_line(c,x,y,x2,y2,time*1.7+k*.2,BLUE,k+tick)

    for i in range(round(84+156*high+106*attack)):
        v=hash16(1271+i*571)
        u=(time*(.25+(v%11)*.032)+(v%103)/103)%1
        x=(v%91)+13*math.sin(u*8+time+i*.05)+near*4
        y=29-26*u
        tone=RED if red>.45 and i%27==0 else VIOLET if i%12==0 else NORMAL if i%6==0 else DEEP
        c.put(x,y,cell(i,tick,BITS),tone)
    if attack>.25:
        for i in range(round(3+attack*6)):
            y=5+(i*4+tick)%23
            x=5+(tick*7+i*41)%65
            c.put(x,y,strbits(i*321+tick,round(15+attack*30),"01:+"),VIOLET if i%2 else NORMAL)


def op_panels(c,time,attack,red,variant):
    """Read/write buses respond to each audible strike, then settle."""
    tick=int(time*12)
    width=16 if variant%3==0 else 13
    positions=(
        ((2,5),(89,6),(2,21),(92,20)),
        ((7,5),(26,21),(72,4),(89,22)),
        ((3,9),(4,21),(88,4),(83,19)),
        ((13,4),(1,21),(74,6),(91,19)),
    )[variant%4]
    for k,(x,y) in enumerate(positions):
        state=(tick//2+k+variant)%5
        name=("RX","TX","SYNC","ACK","LOCK")[state]
        hot=(attack>.33 and (int(time*5+k*1.1)+variant)%3!=0)
        brush=RED if hot and red>.22 else BRIGHT if hot else VIOLET
        c.box(x,y,width,5,brush)
        c.put(x+1,y+1,f"{name} {hash16(tick+k):04X}",brush)
        c.put(x+1,y+3,strbits(variant*921+k+tick,width-2,"01-"),NORMAL if hot else BLUE)
        center=(43+((variant*13+k*3)%24),8+(variant*5+k*3)%17)
        packet_line(c,x+width/2,y+2,*center,time*2.5+k*.25,BLUE if k%2 else DEEP,tick+k)


def mechanism(c,s,bands,attack,red):
    time=s.t
    bass,mid,high=bands
    tick=int(time*17)
    variant=s.seed%14
    op_panels(c,time,attack,red,variant)
    if time>=168.2:
        fill=min(.76,.28+attack*.44+high*.22)
        digits(c,fill*.67,time,"frame" if variant%2 else "crush",red)
    for lane in range(round(13+10*mid+12*attack)):
        n=hash16(lane*1079+variant*3103+1393)
        velocity=1.3+(n%40)*.034+attack*.9
        u=(time*velocity+.017*(n%403))%1
        direction=(variant+lane)%5
        x_center=53+(n%33)-16
        y_center=16+((n//19)%11)-5
        stop=round(8+high*16+attack*12)
        for k in range(stop):
            v=k/stop
            z=(u-v*.25)%1
            if direction in (0,1):
                x=z*108 if direction else 107-z*107
                y=(5+(n//13)%22)+v*math.sin(time*4+lane)*3
            elif direction==2:
                x=x_center+38*(z-.50)
                y=4+z*25
            elif direction==3:
                x=107*z
                y=28-z*24+(n%19)/4
            else:
                x=x_center+16*math.sin(z*11+lane)
                y=y_center+(z-.5)*17
            if not 0<=x<108: continue
            tone=(RED if red>.31 and (lane+k)%17==0 else BRIGHT if k<2 and attack>.38
                  else VIOLET if (lane+variant)%7==0 else NORMAL if k%7==0 else BLUE)
            c.put(x,y,cell(k+lane*19,tick,CHARS if lane%4==0 else BITS),tone)
    if attack>.24:
        for i in range(round(2+attack*10)):
            n=hash16(i*923+variant*704)
            x=8+n%87
            y=6+(n//127)%20
            shift=round(attack*8)
            c.put(x+shift*(i%3-1),y,strbits(n+tick,5+i%8,"01%#"),RED if red>.36 and i%4==0 else BRIGHT)


def spectral_triplet(values,fallback):
    if values is None:
        return fallback,.65*fallback,.50*fallback
    return (fmean(values[:9]),fmean(values[12:31]),
            fmean(values[32:]))


def extra_fill(c,time,red):
    for start,end,style in FILL_EVENTS:
        if start<=time<end:
            p=(time-start)/(end-start)
            strength=ease(p/.26) if p<.26 else 1-ease((p-.55)/.45)
            digits(c,strength*(.77 if style in ("frame","crush") else .99),time,style,red)
            return


class ClimaxLayers:
    def draw(self,c,scene,index,values):
        time=scene.t
        bands=spectral_triplet(values,scene.bass)
        red=hit(time,RED_BEATS,.25)
        if opening(c,time) or prelude(c,time,bands[0]):
            return
        if 58.71<=time<71.77:
            attack=hit(time,FIRST_DRIVER,.23)
            water_interactions(c,scene,bands,attack,red)
        elif DROP_START<=time<179.75:
            attack=hit(time,SECOND_DRIVER,.26)
            mechanism(c,scene,bands,attack,red)
        extra_fill(c,time,red)
        if red>.45 and time<179.75:
            y=5+(index*7)%22
            x=4+(index*17)%61
            c.put(x,y,strbits(int(time*170),12+round(12*red),"0F1:!"),RED)
