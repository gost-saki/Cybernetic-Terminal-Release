"""Chromatic scanline displacement from the HELP ME scene into the ECG."""
from itertools import chain

from cybernetic import ease, hash16
from terminal_timing import IDLE_START, OUTRO


TEAR_PEAK = 179.18
TEAR_RELEASE = 179.40
TEAR_COLORS = {
    49: (46, 196, 225), 50: (121, 108, 230), 51: (219, 90, 212),
    52: (241, 84, 118), 53: (225, 174, 78), 54: (97, 193, 141),
    55: (81, 113, 177),
}
CHANNELS = tuple(TEAR_COLORS)
NOISE = "─+=:/··F0C#"


def paint_signal_tear(canvas, time, bass, incoming=None):
    advance = ease((time - IDLE_START) / (TEAR_PEAK - IDLE_START))
    release = ease((time - TEAR_RELEASE) / (OUTRO - TEAR_RELEASE))
    release_rank = release * 65535
    block_amount = round(4 * advance * (1 - release))
    width, height = canvas.w, canvas.h - 1
    tick = int(time * 13)
    for y, row in enumerate(canvas.cells[:height]):
        band = y // 2
        seed = hash16(band * 251 + tick * 1277)
        if advance < 1 and seed % 100 > 18 + 82 * advance:
            continue
        row_range = .45 + .55 * (seed % 21) / 20
        proportion = .045 + .955 * advance
        reach = ((width + 1) // 2 if advance >= 1 else
                 max(2, round(width * .5 * proportion * (row_range + (1 - row_range) * advance))))
        shift = (1 if seed & 1 else -1) * round(2 + (width * .165 + 9 * bass) * advance)
        original = tuple(row)
        channel_width = 3 + seed % 6
        channel_start = seed // 17 + y % 2
        reveals = (tuple(hash16(band * 1097 + group * 151 + 7103) < release_rank
                         for group in range((width + 4) // 5)) if incoming is not None else ())
        for x in chain(range(reach), range(max(reach, width - reach), width)):
            if reveals and reveals[x // 5]:
                row[x] = incoming.cells[y][x]
                continue
            color = CHANNELS[(x // channel_width + channel_start) % len(CHANNELS)]
            sample = original[(x + shift) % width][0]
            mark = hash16(x * 107 + seed * 37)
            if advance < .52 and mark % 10 < 5 - 4 * advance:
                continue
            if sample.strip() and mark % 4 < 2:
                char = sample
            elif mark % 17 < block_amount:
                char = "▓" if mark & 1 else "░"
            else:
                char = NOISE[mark % len(NOISE)]
            row[x] = (char, color)
