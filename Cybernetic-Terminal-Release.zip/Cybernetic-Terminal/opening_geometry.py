"""Individual opening compositions. Each uses the same proportional stage."""
from math import cos, sin, tau

from cybernetic import hash16
from player import NORMAL, WHITE
from terminal_art import RED_EDGE
from visual_variation import BLUE, DEEP, VIOLET


def fingers(b, time, bass, bands):
    for side in (0, 1):
        for i in range(11):
            x = .045 + i * .037 + side * .525
            length = .13 + bands[(i * 3 + side * 5) % len(bands)] * .23
            tip = .12 + length if side == 0 else .88 - length
            base = .12 if side == 0 else .88
            active = (int(time * 13) + side * 4) % 11 == i
            b.line(x, base, x, tip, "║", NORMAL if active else BLUE)
            b.point(x, tip, "◆" if active else "╵" if side else "╷", VIOLET)
    b.label(.47, .50, "I/O", WHITE)


def shutter(b, time, bass, bands):
    for i in range(13):
        x = .11 + i * .065
        y = .23 + min(i, 12 - i) * .044
        b.line(x, y, x, 1 - y, ":", DEEP)
        travel = (time * 1.3 + i * .095) % 1
        b.point(x, y + travel * (1 - 2 * y), "▰", NORMAL if i % 3 else VIOLET)
        b.point(x, y, "+", BLUE)
        b.point(x, 1 - y, "+", BLUE)
    for i in range(7):
        y = .32 + i * .062
        b.line(.472, y, .527, y, "╱", RED_EDGE if bass > .50 else VIOLET)


def split(b, time, bass, bands):
    for i in range(7):
        spread = .047 + i * .052
        ink = NORMAL if i == int(time * 10) % 7 else BLUE
        b.line(.09, .5, .67, .5 - spread, "·", ink)
        b.line(.09, .5, .67, .5 + spread, "·", VIOLET if i % 2 else BLUE)
        b.point(.69, .5 - spread, ">", ink)
        b.point(.69, .5 + spread, ">", ink)
    b.point(.09, .5, "◆", WHITE)


def through(b, time, bass, bands):
    for i in range(5):
        x = .06 + i * .22
        y = .10 + (i % 2) * .12
        b.line(x, y, x, y + .20, "╎", BLUE)
        b.line(x, 1 - y, x, .8 - y, "╎", VIOLET)
        b.point(x, y + .20, "◆" if i == int(time * 11) % 5 else "+", NORMAL)
        b.point(x, .8 - y, "+", BLUE)


def sensor(b, time, bass, bands):
    for i in range(10):
        r = i / 9
        x = .20 + r * .60
        y = .14 + r * .70
        b.line(x, y, .67 + r * .18, y, "·", DEEP if i % 3 else BLUE)
        b.point(x, y, "○" if i % 3 else "+", VIOLET)
        b.point(.67 + r * .18, y, "+", BLUE)
    k = (time * .54) % 1
    b.point(.2 + k * .60, .14 + k * .70, "◆", NORMAL)


def ladder(b, time, bass, bands):
    for i in range(6):
        x = .15 + .115 * i
        y = .73 - i * .085
        b.line(x, y, x + .105, y, "═", BLUE if i % 2 else VIOLET)
        b.line(x, y, x, .87, "┊", DEEP)
        live = i == int(time * 9) % 6
        b.point(x, y, "◈" if live else "+", NORMAL if live else BLUE)
        b.point(x + .105, y, "×", BLUE)


def packet(b, time, bass, bands):
    for i in range(9):
        x = .13 + i * .09
        shelf = .14 + (i % 3) * .10
        edge = .27 if i % 2 else .73
        b.line(x, shelf, x, 1 - shelf, "┆", BLUE if i % 2 else VIOLET)
        b.point(x, edge, "o", NORMAL)
        k = (time * .9 + i * .17) % 1
        size = 2 + ((i * 17) % 5)
        b.point(x - .025, shelf + k * (1 - 2 * shelf), "■" * size,
                NORMAL if i % 3 == 0 else VIOLET)
        b.point(x, .86 - (i % 2) * .046, "╵" if i % 2 else "╷", BLUE)
        if i % 3 == 1:
            b.point(x - .02, shelf + .062, f"{round(31 * bands[i * 4]):02X}", DEEP)
    b.label(.13, .08, "TX", NORMAL)
    b.label(.86, .91, "RX", VIOLET)


def bus(b, time, bass, bands):
    for i in range(11):
        p = i / 10
        x, y = .12 + .69 * p, .76 - .53 * p
        ink = VIOLET if i % 3 == 0 else BLUE
        b.point(x, y, "░▒▓" if i == int(time * 15) % 11 else "┯┯┯", ink)
        b.line(x, y, x, y + .14, "┊", BLUE if i % 2 else DEEP)
        b.point(x, y + .14, "╵", NORMAL if i % 2 else BLUE)
    b.point(.86, .21, "◆", NORMAL)


def release(b, time, bass, bands):
    for i in range(19):
        seed = hash16(i * 2813)
        x = .14 + (seed % 73) * .01
        y = .15 + (seed // 73 % 61) * .01
        shift = (time * .72 + i * .11) % 1
        b.point(x, y + .12 * shift, "╷" if i % 2 else "·", BLUE)
        b.point(x + .09 * shift, y + .18 * shift, "·" if i % 3 else "◦",
                VIOLET if shift < .55 else DEEP)


def skew(b, time, bass, bands):
    for i in range(5):
        y = .21 + .132 * i
        width = .19 + .24 * bands[i * 7]
        x = .08 + .12 * i
        shift = .05 * sin(time * 11 + i)
        ink = VIOLET if i % 2 else NORMAL
        b.line(x + .06, y, x + width, y, "▒", BLUE)
        b.line(x + .06 + shift, y + .075, x + width + shift, y + .075, "░", ink)
        b.point(x, y, "▰", ink)


def hurt(b, time, bass, bands):
    for i in range(16):
        v = (i + .5) / 16
        seed = hash16(i * 3571)
        y = .14 + .19 * (seed % 29) / 28
        x = .50 + (v - .50) * .98
        b.line(x, y, x + (v - .5) * .04, y - .14, "╱", VIOLET if i % 2 else RED_EDGE)
        b.line(1 - x, 1 - y, 1 - x + (.5 - v) * .045, 1 - y + .12, "╲", BLUE)


def tether(b, time, bass, bands):
    for i in range(55):
        p = i / 54
        bow = sin(p * tau + time * 3) * sin(p * tau / 2) * .14
        x = .11 + .78 * p
        upper, lower = .22 + .46 * p + bow, .81 - .52 * p - bow
        b.point(x, upper, "·" if i % 4 else "o", NORMAL)
        b.point(x, lower, "·" if i % 4 else "o", VIOLET)
        if i % 9 == 0:
            b.line(x, upper, x, lower, "╎", DEEP)
    b.point(.11, .22, "◆", WHITE)
    b.point(.89, .29, "◆", VIOLET)


def stack(b, time, bass, bands):
    for i in range(6):
        inset = i * .052
        x, y = .11 + inset, .14 + i * .12
        b.line(x, y, x + .42, y, "═", BLUE if i % 2 else VIOLET)
        b.line(x + .42, y, x + .42, y + .073, "┊", BLUE)
        b.point(x - .067, y, f"{i * 16:02X}", NORMAL)
        b.point(x + .447, y + .045, "▰" if i == int(time * 10) % 6 else "·", NORMAL)


def bank(b, time, bass, bands):
    for y in range(5):
        for x in range(14):
            value = bands[(x + y * 7) % len(bands)]
            scan = (int(time * 12) + y * 3) % 14 == x
            mark = "▓▓" if scan else "▒▒" if value > .45 else "░░"
            b.point(.13 + x * .052, .22 + y * .137, mark, NORMAL if scan else VIOLET if value > .45 else BLUE)
        b.point(.87, .22 + y * .137, f"{y * 14:02X}", BLUE)


def readout(b, time, bass, bands):
    for i in range(27):
        x = .10 + i * .029
        strength = bands[i * len(bands) // 27]
        y = .77 - (.09 + .62 * strength)
        b.line(x, .77, x, y, "┊", BLUE if i % 4 else VIOLET)
        b.point(x, y, "◆" if i % 4 == 0 else "·", NORMAL)
    for i in range(4):
        b.point(.05, .21 + i * .18, f"{(3 - i) * 8:02d}", BLUE)


def antenna(b, time, bass, bands):
    b.line(.5, .33, .5, .79, "║", NORMAL)
    b.line(.5, .33, .32, .79, "╱", BLUE)
    b.line(.5, .33, .68, .79, "╲", VIOLET)
    for i in range(4):
        radius = .10 + i * .09
        phase = (time * .81 - i * .31) % 1
        for n in range(12):
            a = tau * (n / 34 + .34)
            b.point(.5 + radius * cos(a), .37 - radius * sin(a) * .68,
                    "·" if n % 3 else "╵", NORMAL if phase < .30 else BLUE)
    b.point(.5, .33, "◆", WHITE)


def salvage(b, time, bass, bands):
    for i in range(14):
        seed = hash16(i * 617)
        x = .14 + .70 * (seed % 71) / 70
        y = .22 + .62 * (seed // 71 % 53) / 52
        l = .025 + .052 * (seed % 9) / 8
        b.line(x, y, x + l, y - .065, "╱", VIOLET if i % 4 == 0 else BLUE)
    travel = (time * .51) % 1
    b.line(.22 + travel * .56, .19, .13 + travel * .56, .82, "·", NORMAL)
    b.point(.22 + travel * .56, .19, "◆", NORMAL)


def recovery(b, time, bass, bands):
    aim = .41 + .037 * sin(time * 2)
    for i in range(11):
        u = i / 10
        head = (time * .88 + u * .74) % 1
        x = aim + (u - .5) * .77 * (1 - head)
        y = .82 - .68 * head
        ink = VIOLET if i % 3 else NORMAL
        b.line(x, y, x + (u - .5) * .10, y + .11, "·", ink)
        b.point(x, y, "◆" if i % 4 == 0 else "╵", ink)
    for sign in (-1, 1):
        b.line(aim + sign * .16, .23, aim + sign * .048, .13, "╱" if sign < 0 else "╲", BLUE)
        b.line(aim + sign * .21, .24, aim + sign * .15, .18, "·", BLUE)
        b.point(aim + sign * .054, .13, "╶" if sign < 0 else "╴", NORMAL)
    b.point(aim, .13, "✦", WHITE)
    b.label(.71, .26, "LOCK", BLUE)


def identity(b, time, bass, bands):
    for i in range(25):
        x = .05 + i * .037
        y = .21 + .052 * sin(i * .53 + time * 4)
        b.point(x, y, "╴" if i % 3 else "+", NORMAL if i % 5 == 0 else BLUE)
        b.point(1 - x, 1 - y, "╶" if i % 3 else "+", VIOLET)


def echo(b, time, bass, bands):
    for i in range(7):
        spread = .115 + i * .048
        cx = .48 + i * .012
        cy = .45 + .024 * sin(time * 4 - i * .7)
        tall = .12 + i * .047
        ink = NORMAL if i == int(time * 8) % 7 else VIOLET if i % 3 == 0 else BLUE
        b.line(cx - spread, cy, cx, cy - tall, "╱", ink)
        b.line(cx, cy - tall, cx + spread, cy, "╲", ink)
        b.line(cx + spread, cy, cx, cy + tall, "╱", ink)
        b.line(cx, cy + tall, cx - spread, cy, "╲", ink)
        b.point(cx + spread, cy, "•", ink)


COMPOSITIONS = {
    "pins": fingers, "barrier": shutter, "fork": split, "through": through,
    "scope": sensor, "relay": ladder, "packet": packet, "bus": bus, "release": release,
    "skew": skew, "hurt": hurt, "tether": tether,
    "memory": stack, "bank": bank, "readout": readout, "beacon": antenna,
    "rescue": salvage, "recovery": recovery, "identity": identity, "echo": echo,
}
