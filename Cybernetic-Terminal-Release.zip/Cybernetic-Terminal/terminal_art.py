"""Draw the decoded portrait maps as colored characters, never as bitmaps."""
import math

from cybernetic import hash16, ease
from player import BRIGHT, NORMAL, WHITE
from visual_variation import BLUE, DEEP, VIOLET


GLITCH_START, GLITCH_END = 77.0, 80.0
CODE = "01X79ACE38F4B625"
SPARSE_BEAT_TARGETS = (
    3.46, 10.53, 19.64, 34.62, 47.34, 61.39, 70.07,
    82.805, 111.90, 136.20, 158.26, 169.17,
)
GREEN = 14
CYAN_EDGE, PURPLE_EDGE, RED_EDGE = 15, 16, 17
ICE, LILAC = 20, 28


def sparse_hits(candidates):
    return tuple(min(near, key=lambda time: abs(time - target))
                 for target in SPARSE_BEAT_TARGETS
                 if (near := [time for time in candidates if abs(time - target) <= .57]))


def calculate_row(grid, y, height, columns):
    source = grid[y * len(grid) // height]
    return [ord(source[x * len(source) // columns]) - 65 for x in range(columns)]


def glitch_row(canvas, x0, y, values, tick, bass, dissolve, strength):
    active = [x for x, value in enumerate(values) if value]
    if not active:
        return
    left, right = active[0], active[-1]
    belt = max(3, min(12, (right - left) // 5))
    hash_row = hash16((y // 2) * 1761 + tick * 441)
    for i in active:
        value = values[i]
        seed = hash16(i * 643 + y * 173 + tick * 337)
        rank = hash16(9221 + i * 647 + y * 977) / 65535
        if dissolve and rank < dissolve:
            continue
        distance = min(i - left, right - i)
        direction = -1 if i * 2 < left + right else 1
        if distance < belt:
            power = (1 - distance / belt) * (.35 + .65 * bass)
            drift = direction * round(power * (2 + hash_row % 6))
            if strength > .8 and seed % 19 < 5 * power * (1 - dissolve):
                canvas.put(x0 + i + drift + direction * (2 + seed % 7), y,
                           CODE[seed & 15], PURPLE_EDGE if direction > 0 else CYAN_EDGE)
            i += drift if hash_row % 3 == 0 else 0
        if dissolve:
            i += direction * round(dissolve * (3 + seed % 11))
        palette = LILAC if value & 8 else ICE
        tone = palette + max(1, round((value & 7) * strength * (1 - .65 * dissolve)))
        if distance < belt and seed % 19 in (4, 13) and dissolve < .2 and strength > .8:
            tone = RED_EDGE
        mark = ":" if dissolve > .18 and rank - dissolve < .3 else CODE[seed & 15]
        canvas.put(x0 + i, y, mark, tone)

    if strength > .8 and dissolve < .3 and hash_row % 8 < 2 + round(2 * bass):
        x = left if hash_row % 2 else right
        sign = -1 if x == left else 1
        for j in range(1, 4 + hash_row % 6):
            offset = sign * (j + 3)
            canvas.put(x0 + x + offset, y, CODE[(hash_row + j * 13) & 15],
                       CYAN_EDGE if sign < 0 else PURPLE_EDGE)


def paint_character(canvas, grid, time, bass, *, foreground=False, dissolve=0.0, strength=1.0):
    height = canvas.h - 1
    width = min(canvas.w, round(height * 2.43))
    left = (canvas.w - width) // 2
    tick = round((time - GLITCH_START) * 22)
    for y in range(height):
        values = calculate_row(grid, y, height, width)
        if foreground:
            row = canvas.cells[y]
            lit = [x for x, value in enumerate(values) if value]
            start, end = (left + lit[0], left + lit[-1] + 1) if lit else (0, 0)
            # Protect the facial shadows, revealing the stage in scattered cells on exit.
            if not dissolve:
                row[:] = [(" " if start <= x < end else char, DEEP)
                          for x, (char, _) in enumerate(row)]
            else:
                for x, (char, _) in enumerate(row):
                    if hash16(913 + x * 647 + y * 977) / 65535 >= dissolve:
                        row[x] = (" " if start <= x < end else char, DEEP)
        glitch_row(canvas, left, y, values, tick, bass, dissolve, strength)


def paint_art(canvas, grid, x0, y0, width, height, t=0.0, strength=1.0,
              *, blink=None, raw=False, behind=False, skip_rows=(), clear_body=False):
    if not grid or width < 1 or height < 1:
        return
    for y in range(height):
        pos_y = y0 + y
        if pos_y < 0 or pos_y >= canvas.h or pos_y in skip_rows:
            continue
        values = calculate_row(grid, y, height, width)
        if clear_body or (raw and behind):
            lit = [x for x, value in enumerate(values) if value]
            if lit and clear_body:
                canvas.put(x0 + lit[0], pos_y, " " * (lit[-1] - lit[0] + 1), DEEP)
            if lit and raw and behind and strength > .4:
                for col, color in ((x0 + lit[0] - 1, CYAN_EDGE), (x0 + lit[-1] + 1, PURPLE_EDGE)):
                    if 0 <= col < canvas.w and canvas.cells[pos_y][col][0] == " ":
                        canvas.put(col, pos_y, ":" if y % 3 else "1", color)
        for x, value in enumerate(values):
            power = value & 7
            if blink is not None:
                mouth_x, mouth_y, jaw = blink
                dx = x / width - mouth_x
                dy = y / height - mouth_y + dx * .25
                if (dx / .038) ** 2 + (dy / (.013 + .020 * jaw)) ** 2 <= 1:
                    power = 0
            if not power:
                continue
            col = x0 + x
            if not 0 <= col < canvas.w or (behind and canvas.cells[pos_y][col][0] != " "):
                continue
            seed = hash16(x * 643 + y * 173 + int(t * 16) * 337)
            tone = (LILAC if value & 8 else ICE) + max(1, round(power * strength))
            code = "01#@"[seed % 4] if raw else CODE[seed & 15]
            canvas.put(col, pos_y, code, tone)


def title_cover(canvas, portrait):
    for y in range(1, canvas.h - 3):
        for x in range(1, canvas.w - 4, 9):
            seed = hash16(y * 193 + x * 263)
            if seed % 7:
                canvas.put(x, y, "".join(CODE[(seed + k * 23) & 15] for k in range(3 + seed % 5)),
                           DEEP if seed % 4 else BLUE)
    height = canvas.h - 2
    width = min(round(height * 1.7), round(canvas.w * .52))
    paint_art(canvas, portrait, canvas.w - width - 2, 0, width, height, raw=True, clear_body=True)
    y = canvas.h // 2 - 4
    title_width = 59 if canvas.w >= 96 else max(32, canvas.w // 2)
    for row in range(y - 1, y + 9):
        canvas.put(1, row, " " * (title_width + 1), DEEP)
    if canvas.w >= 96:
        from player import FONT
        for index, char in enumerate("CYBERNETIC"):
            for dy, row in enumerate(FONT[char]):
                for dx, bit in enumerate(row):
                    if bit == "1":
                        code = CODE[hash16(index * 919 + dx * 137 + dy * 31) & 15]
                        canvas.put(2 + index * 6 + dx, y + dy, code, WHITE)
    else:
        canvas.put(3, y + 2, "CYBERNETIC", WHITE)
    if canvas.w >= 96:
        canvas.put(3, y + 6, "CYBERNETIC", WHITE)
    canvas.put(3, y + 7, "-" * min(40, title_width - 6), VIOLET)
    canvas.put(3, y + 8, "SPACE / START", BRIGHT)


def jaw_at(age, markers, bass):
    attack = max(math.exp(-((age - marker - .095) / .096) ** 2) for marker in markers)
    return ease(min(1, attack * (.73 + .33 * bass)))
