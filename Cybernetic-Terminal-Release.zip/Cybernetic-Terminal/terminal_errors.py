"""Accumulate red ERROR stamps, then break them up into the following cut."""
from functools import lru_cache

from cybernetic import ease, hash16
from terminal_art import GLITCH_END, GLITCH_START
from terminal_finale import COMPACT, WIDE, block_points, block_width


ERROR_FULL = 79.63
ERROR_RED, ERROR_DIM, ERROR_DUST = 46, 47, 48


@lru_cache(maxsize=16)
def stamp_layout(width, height, label="ERROR", footer=4):
    font = WIDE if width >= 155 else COMPACT
    label_width = block_width(label, font)
    columns = max(1, (width + 2) // (label_width + 2))
    rows = max(1, (height - footer) // 6)
    x_space = max(0, width - label_width)
    y_space = max(0, height - footer - 5)
    stamps = [
        (round(x_space * col / max(1, columns - 1)),
         round(y_space * row / max(1, rows - 1)))
        for row in range(rows) for col in range(columns)
    ]
    first = min(stamps, key=lambda p: (p[0] / width - .16) ** 2 + (p[1] / height - .09) ** 2)
    stamps.remove(first)
    stamps.sort(key=lambda p: hash16(3419 + p[0] * 631 + p[1] * 1879))
    return (first, *stamps), block_points(label, font), label_width


def release_at(time):
    return ease((time - ERROR_FULL) / (GLITCH_END - ERROR_FULL))


def paint_errors(canvas, time):
    fill = (time - GLITCH_START) / (ERROR_FULL - GLITCH_START - .12)
    paint_stamps(canvas, "ERROR", (0, 0, canvas.w - 1, canvas.h - 1),
                 fill, release_at(time), footer=4)


def paint_stamps(canvas, label, box, fill, release, *, footer=0, clip=None):
    x0, y0, x1, y1 = box
    room = x1 - x0 + 1
    stamps, points, label_width = stamp_layout(room, y1 - y0 + 1, label, footer)
    clip_left, clip_right = (x0, x1) if clip is None else clip
    fill = min(1, max(0, fill))
    active = 1 + int((len(stamps) - 1) * fill ** 1.25)
    for i, (left, top) in enumerate(stamps[:active]):
        seed = hash16(2711 + i * 577)
        at_exit = release * (1.13 + (seed % 21) / 100)
        shift = round(release * (4 + seed % 13))
        direction = 1 if left + label_width / 2 >= room / 2 else -1
        tint = ERROR_DIM if i and seed % 4 == 1 else ERROR_RED
        for x, y in points:
            rank = hash16(seed + x * 11_147 + y * 2879) / 65535
            if rank <= at_exit and release > 0:
                continue
            dx = direction * shift
            dy = round(release * ((seed >> 3) % 7 - 3))
            if release > .25 and rank < at_exit + .2:
                mark, style = ("1" if rank > .65 else ":"), ERROR_DUST
            else:
                mark, style = "█", tint
            row = y0 + top + y + dy
            col = x0 + left + x + dx
            if y0 <= row <= y1 - footer and clip_left <= col <= clip_right:
                canvas.put(col, row, mark, style)
