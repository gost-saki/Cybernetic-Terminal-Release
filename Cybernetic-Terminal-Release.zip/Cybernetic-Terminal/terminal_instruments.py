"""Geometry primitives for the opening and the first chorus log panels."""
from math import cos, sin, tau

from cybernetic import hash16
from player import BRIGHT, NORMAL, WHITE
from terminal_art import CYAN_EDGE, PURPLE_EDGE
from visual_variation import BLUE, DEEP, VIOLET, frame_clock


LOG_START = 59.0
RX = ("RETRY", "SALT", "WET BYTE", "GHOST", "CACHE", "NO PORT", "LOST", "ECHO?", "DROP")
TX = ("FLOAT", "DRIFT", "NO ACK", "RELAY", "AFLOAT", "FEEDBACK", "OVERRUN", "NULL", "FLUX")
LOG_COLORS = (NORMAL, 8, 9, 10, 11, 12, CYAN_EDGE, PURPLE_EDGE)
DOTS = ".,:+'"


def panel(canvas, left, top, width, height, title, time, words, seed):
    for y in range(top, top + height):
        canvas.put(left, y, " " * width, DEEP)
    canvas.box(left, top, width, height, BLUE)
    canvas.put(left + 1, top, title[:width - 2], NORMAL)
    tick = int(time * 8)
    for i in range(height - 2):
        value = hash16(seed * 2917 + (i + tick) * 1229)
        ink = LOG_COLORS[(value // 19 + i) % len(LOG_COLORS)]
        word = words[value % len(words)]
        token = f"{value >> 8:02X} {word}" if width >= 12 else word
        if i % 5 == 3:
            token = f"{value:04X}:{value % 71:02d}"
        canvas.put(left + 2, top + 1 + i, token[:width - 3], ink)


def plot(canvas, area, u, v, char, style):
    left, top, right, bottom = area
    if 0 <= u <= 1 and 0 <= v <= 1:
        canvas.put(round(left + (right - left) * u), round(top + (bottom - top) * v), char, style)


def orbital_trace(canvas, area, time, bass):
    slope = .085 if time < 3.48 else -.11 if time < 6.45 else .16
    for arm in range(2):
        for i in range(106):
            angle = tau * (i / 106) + arm * 1.55
            x = .5 + .40 * cos(angle)
            y = .50 + .31 * sin(angle) * (1 if arm else -.85) + slope * cos(angle)
            leading = (i - int(time * 27) - arm * 36) % 106
            if leading < 13:
                char, style = "•", WHITE if bass > .5 else BRIGHT
            elif i % 13 == 0:
                char, style = "+", NORMAL
            else:
                char, style = DOTS[(i + arm) % len(DOTS)], BLUE if arm else VIOLET
            plot(canvas, area, x, y, char, style)
    for x, y in ((.18, .23), (.5, .5), (.82, .77)):
        plot(canvas, area, x, y, "+", NORMAL)


def routing_rack(canvas, area, time, bass):
    left, top, right, bottom = area
    gap = right - left
    height = bottom - top
    channel_x = [left + round(gap * p) for p in (.10, .33, .56, .88)]
    rows = [top + round(height * p) for p in (.22, .48, .73)]
    for i, y in enumerate(rows):
        a, b, c, d = channel_x
        lane = rows[(i + 1) % len(rows)]
        canvas.line(a, y, b, y, "-", VIOLET)
        canvas.line(b, y, b, lane, ":", DEEP)
        canvas.line(b, lane, d, lane, "-", VIOLET if i % 2 == 0 else BLUE)
        for j, x in enumerate((a, b, c, d)):
            canvas.put(x - 1, y, "[+]" if j % 2 else "<o>", NORMAL if j < 2 else VIOLET)
        phase = (time * .68 + i * .31) % 1
        cursor = round(a + phase * (d - a))
        canvas.put(cursor, y if cursor < b else lane, "=>", BRIGHT if bass > .25 else NORMAL)


def sonar(canvas, area, time, bass):
    # Concentric dotted rings change their vertical spacing with the low band.
    head = (time * .42) % 1
    for ring in range(1, 5):
        radius = .105 * ring
        for i in range(52):
            phi = i / 52
            angle = tau * phi
            leading = (head - phi) % 1 < .078
            if i % 2 != 0 and not leading:
                continue
            x = .5 + radius * cos(angle)
            y = .5 + radius * (.87 + .12 * bass) * sin(angle)
            char = "+" if leading else "." if i % 2 else ":"
            plot(canvas, area, x, y, char, BRIGHT if leading else VIOLET if ring % 2 else BLUE)
    plot(canvas, area, .50, .50, "+", WHITE)


def aperture(canvas, area, time, bass):
    left, top, right, bottom = area
    width, height = right - left, bottom - top
    phase = (sin(time * 3.6) + 1) / 2
    for i in range(3):
        pad = .055 + i * .12 + .045 * phase
        x = left + round(width * pad)
        y = top + round(height * pad)
        canvas.box(x, y, right - x - round(width * pad) + 1,
                   bottom - y - round(height * pad) + 1, VIOLET if i == 1 else BLUE)
    for i in range(7):
        plot(canvas, area, .5 + (i - 3) * .042, .5, "+" if i < 2 + 5 * bass else ".", NORMAL)


def paint_instruments(canvas, time):
    width, height = canvas.w, canvas.h
    panel_width = max(8, min(24, round(width * .125)))
    left_x = 1
    right_x = width - panel_width - 1
    top, bottom = 3, height - 7
    if width < 108 and not 64.61 <= time < 65.47:
        for y in range(top):
            canvas.put(0, y, " " * width, DEEP)
        clock = frame_clock(time)
        canvas.put(2, 1, "CYBERNETIC", BRIGHT)
        canvas.put(width - len(clock) - 2, 1, clock, BLUE)
    panel(canvas, left_x, top, panel_width, bottom - top + 1,
          "RX / LEAK" if panel_width >= 13 else "RX", time, RX, 1)
    panel(canvas, right_x, top, panel_width, bottom - top + 1,
          "TX / TIDE" if panel_width >= 13 else "TX", time + .23, TX, 2)
    # Meter ticks leave the original chorus shapes room.
    for x in (left_x + panel_width + 1, right_x - 2):
        for y in range(top + 2, bottom, 3):
            if canvas.cells[y][x][0] == " ":
                canvas.put(x, y, "+" if (y + int(time * 6)) % 5 < 2 else ".", BLUE)
